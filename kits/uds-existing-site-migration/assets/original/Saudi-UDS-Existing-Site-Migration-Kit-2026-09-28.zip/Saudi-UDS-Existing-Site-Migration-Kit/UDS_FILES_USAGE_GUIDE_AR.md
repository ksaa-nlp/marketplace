# دليل استخدام ملفات كود المنصات الموحد

هذا الدليل يشرح كيف تستخدم حزمة الدراسة والتنفيذ الموجودة في المشروع عند تصميم صفحة، تطوير واجهة، مراجعة الامتثال، أو تشغيل وكيل ذكاء اصطناعي.

> **تاريخ مرجع الدراسة:** 7 سبتمبر 2026  
> **المصدر الرسمي المدروس:** <https://design.dga.gov.sa/>  
> **مهم:** هذه الحزمة أداة تنفيذ وتحقق مبنية على المصدر العام. لا تستبدل تقييم الجهة الرسمي أو الاختبارات البشرية المطلوبة.

## 1. البدء السريع

عند إنشاء أو تعديل واجهة:

1. اقرأ [`AGENTS.md`](./AGENTS.md) لمعرفة التعليمات الإلزامية.
2. اختر القالب المناسب من [`.design-system/uds-templates.json`](./.design-system/uds-templates.json).
3. اختر المكونات الرسمية من [`.design-system/uds-components.json`](./.design-system/uds-components.json).
4. استخرج القواعد المناسبة من [`.design-system/uds-rules.json`](./.design-system/uds-rules.json).
5. استخدم القيم الموجودة في [`.design-system/uds-tokens.css`](./.design-system/uds-tokens.css).
6. نفّذ الواجهة ثم شغّل:

```bash
python3 tools/uds-compliance/uds_compliance.py path/to/your-ui
```

7. أصلح كل `FAIL` وراجع كل `WARNING`.
8. أكمل البنود البشرية في [`.design-system/UDS_DEFINITION_OF_DONE.md`](./.design-system/UDS_DEFINITION_OF_DONE.md).
9. اكتب تقريرك النهائي بالصيغة الموجودة في `AGENTS.md`.

## 2. خريطة الملفات

| الملف أو المجلد | وظيفته | متى تستخدمه؟ |
|---|---|---|
| [`AGENTS.md`](./AGENTS.md) | تعليمات ملزمة لوكلاء الذكاء الاصطناعي والمطورين عند تنفيذ UI | اقرأه أولًا قبل أي عمل واجهات |
| [الدليل الرئيسي](./.design-system/Saudi_Unified_Platform_Code_Master_Guide.md) | المرجع البشري الشامل للقواعد والأسس والمكونات والقوالب والمصادر | عند فهم قاعدة أو اتخاذ قرار تصميمي |
| [المرجع السريع](./.design-system/Saudi_Unified_Platform_Code_AI_Quick_Reference.md) | نسخة مختصرة للقراءة السريعة أو للسياق المحدود للذكاء الاصطناعي | عند الحاجة لإجابة أو قرار سريع |
| [القواعد المدققة](./.design-system/Saudi_Unified_Platform_Code_Rules.md) | جدول بشري يضم 169 قاعدة ذرية قابلة للتتبع | عند المراجعة أو البحث بالمعرف |
| [`uds-rules.json`](./.design-system/uds-rules.json) | القواعد نفسها بصيغة مقروءة آليًا | للبرمجة، الفلترة، أدوات CI والوكلاء |
| [`uds-components.json`](./.design-system/uds-components.json) | سجل 50 مكونًا رسميًا وخصائصها المنشورة | قبل اختيار أو بناء أي مكون |
| [`uds-templates.json`](./.design-system/uds-templates.json) | سجل 19 قالبًا رسميًا وبنية كل قالب | عند بدء صفحة جديدة |
| [`uds-tokens.css`](./.design-system/uds-tokens.css) | أسماء محلية مدققة لقيم الألوان والخطوط والمسافات وغيرها | داخل CSS أو طبقة tokens في التطبيق |
| [Definition of Done](./.design-system/UDS_DEFINITION_OF_DONE.md) | قوائم تحقق للتصميم والمكونات وRTL والوصول والاختبار | قبل اعتماد الصفحة أو تسليمها |
| [تقرير التغطية](./.design-system/Saudi_Unified_Platform_Code_Coverage_Report.md) | حدود الدراسة، النتائج، التعارضات، وما لم ينشر رسميًا | عند التدقيق أو تقييم موثوقية معلومة |
| [مخزون الزحف](./.design-system/crawl_inventory.md) | تصنيف 96 صفحة وعناوينها وحالة معالجتها | لتتبع مصدر صفحة أو التأكد من شمولها |
| [`official-resources/`](./official-resources/) | نسخ محلية من الموارد العامة التي تم فحصها | للتحقق من أصل قيمة أو مورد تقني |
| [`tools/uds-compliance/`](./tools/uds-compliance/) | المدقق الساكن والمولدات والاختبارات | للفحص الآلي والصيانة |
| [`uds-validation-demo/`](./uds-validation-demo/) | مثال عربي عملي مع تقارير امتثال | للتعلم أو اختبار المدقق |

## 3. ترتيب الرجوع إلى المصادر

عند وجود سؤال أو تعارض، استخدم الترتيب التالي:

1. الصفحة الرسمية المباشرة والمادة المنشورة فيها.
2. القاعدة المرتبطة بمصدر مباشر في `uds-rules.json`.
3. الدليل الرئيسي لشرح السياق والتطبيق.
4. سجل المكون أو القالب المناسب.
5. المرجع السريع للاختصار، وليس لحسم التعارضات.

إذا تعارض ملفان، لا تختر أحدهما بصمت. سجّل التعارض، وافتح المصدر الرسمي المباشر، واستخدم `NEEDS-VERIFICATION` إذا لم يمكن الحسم.

## 4. فهم مستويات القواعد

كل قاعدة تحتوي على `level`:

| المستوى | طريقة التعامل |
|---|---|
| `REQUIRED` | إلزامي؛ مخالفته تمنع اعتبار التنفيذ مكتملًا |
| `RECOMMENDED` | يطبّق عادة، وأي استثناء يحتاج سببًا موثقًا |
| `OPTIONAL` | يستخدم عندما تدعم حاجة الصفحة اختياره |
| `INFERRED` | توجيه تنفيذي مستنتج؛ لا تنسبه إلى المصدر كقاعدة رسمية مستقلة |

وتحتوي على `testability`:

| التصنيف | معناه |
|---|---|
| `AUTOMATED` | يمكن للمدقق الساكن التحقق منه بدرجة موثوقة |
| `SEMI_AUTOMATED` | يحتاج فحصًا آليًا مع مراجعة بصرية أو تشغيلية |
| `MANUAL` | يحتاج حكمًا أو اختبارًا بشريًا |

وجود قاعدة تحت `MANUAL REVIEW` لا يعني أنها فشلت؛ يعني فقط أن الأداة لا تستطيع إثباتها وحدها.

## 5. استخدام سجل القواعد

للبحث عن قاعدة بالمعرف:

```bash
rg 'UDS-RTL-001' .design-system/uds-rules.json
```

للبحث عن قواعد الوصول:

```bash
rg 'UDS-A11Y-' .design-system/Saudi_Unified_Platform_Code_Rules.md
```

كل مدخل في JSON يحتوي على:

- `id`: معرف ثابت تستخدمه في التقارير والاستثناءات.
- `category`: المجال.
- `level`: درجة الإلزام.
- `rule`: نص القاعدة.
- `source_url` و`source_page_title`: المصدر المباشر.
- `verification_date`: تاريخ آخر تحقق.
- `implementation_notes`: طريقة تطبيق عملية.
- `testability`: طريقة التحقق.

في كود المشروع أو تقرير المراجعة، اذكر معرف القاعدة بدل كتابة وصف عام، مثل: `UDS-RTL-001` أو `UDS-A11Y-008`.

## 6. استخدام سجل المكونات

قبل إنشاء مكون جديد، ابحث في `uds-components.json`:

```bash
rg -n '"component": "button"' .design-system/uds-components.json
```

راجع خصوصًا:

- الغرض و`when_to_use` و`when_not_to_use`.
- `anatomy` و`variants` و`sizes`.
- حالات hover/focus/active/disabled/error/success/loading.
- RTL والاستجابة.
- الوصول ولوحة المفاتيح وARIA.
- المحتوى وDo/Don't.
- `rules` والمصدر المباشر.

إذا كانت القيمة:

```text
NOT PUBLISHED BY OFFICIAL SOURCE
```

فهذا يعني أن المصدر العام لم ينشرها. يمكنك اتخاذ قرار خاص بالمشروع عند الضرورة، لكن يجب وصفه بأنه قرار مشروع أو `INFERRED`، وليس خاصية رسمية للنظام.

## 7. استخدام سجل القوالب

ابدأ كل صفحة باختيار أقرب `template_id`. أمثلة:

| نوع الصفحة | القالب |
|---|---|
| الرئيسية | `UDS-TPL-HOME` |
| خدمة | `UDS-TPL-SERVICE` |
| نموذج | `UDS-TPL-FORM` |
| نتائج بحث | `UDS-TPL-SEARCH` |
| أسئلة شائعة | `UDS-TPL-FAQ` |
| صفحة محتوى | `UDS-TPL-CONTENT` |
| خطأ 404 | `UDS-TPL-404` |

بعد اختيار القالب، راجع:

- الأقسام المنشورة والمطلوبة والاختيارية.
- التسلسل الهرمي للمكونات.
- Header وNavigation وHero والمحتوى وCTA وFooter.
- قواعد RTL والاستجابة والوصول والمحتوى.
- معرفات القواعد والمصادر المباشرة.

إذا لم يوجد قالب مناسب، لا تخترع قالبًا رسميًا. اكتب في التقرير أن التركيب `INFERRED` أو `NEEDS-VERIFICATION`.

## 8. استخدام Design Tokens

أدخل ملف tokens قبل أنماط الصفحة:

```html
<link rel="stylesheet" href="/.design-system/uds-tokens.css">
<link rel="stylesheet" href="/styles.css">
```

ثم استخدم المتغيرات بدل القيم المتكررة:

```css
.example-card {
  color: var(--uds-color-neutral-900);
  background: var(--uds-color-neutral-0);
  padding: var(--uds-space-6);
  border-radius: var(--uds-radius-md);
}
```

أسماء `--uds-*` هي aliases خاصة بهذا المستودع وموسومة `INFERRED`، بينما القيم مدققة من المادة الرسمية العامة. إذا كان المشروع لديه نظام tokens، اربط نظامه بهذه القيم بدل إنشاء طبقتين متنافستين.

## 9. استخدام مدقق الامتثال

### فحص مجلد واجهة

```bash
python3 tools/uds-compliance/uds_compliance.py src
```

### إنشاء تقريري JSON ونص

```bash
python3 tools/uds-compliance/uds_compliance.py src \
  --json-out reports/uds-compliance.json \
  --text-out reports/uds-compliance.txt
```

### الوضع الصارم

```bash
python3 tools/uds-compliance/uds_compliance.py src --strict
```

رموز الخروج:

- `0`: لا توجد حالات فشل؛ وقد توجد تحذيرات دون `--strict`.
- `1`: توجد مخالفة آلية إلزامية.
- `2`: لا توجد حالات فشل، لكن الوضع الصارم وجد تحذيرات.

معاني النتائج:

- `PASS`: لم يجد المدقق مخالفة للقاعدة الآلية.
- `FAIL`: مخالفة يجب إصلاحها قبل الاعتماد.
- `WARNING`: احتمال مخالفة أو حالة تحتاج قرارًا.
- `MANUAL REVIEW`: قاعدة لا يستطيع التحليل الساكن إثباتها.

راجع شرح المدقق الكامل في [`tools/uds-compliance/README.md`](./tools/uds-compliance/README.md).

## 10. سير عمل المطور

1. حدد نوع الصفحة والمهمة الأساسية واللغة والحالات المتوقعة.
2. دوّن `template_id` المختار.
3. دوّن أسماء المكونات الرسمية المطلوبة.
4. اجمع Rule IDs ذات الصلة.
5. أنشئ الهيكل الدلالي قبل التنسيق.
6. طبّق `lang="ar"` و`dir="rtl"` للواجهة العربية.
7. استخدم tokens وابدأ من الجوال.
8. نفّذ الحالات المنشورة للمكونات.
9. اختبر لوحة المفاتيح والتركيز والرسائل والأخطاء.
10. شغّل المدقق وأصلح النتائج.
11. أكمل Definition of Done.
12. سلّم تقرير الامتثال مع الاستثناءات.

## 11. سير عمل المصمم

1. اختر القالب الرسمي الأقرب.
2. استخدم المكونات المنشورة بدل رسم بدائل جديدة.
3. اربط الألوان والخطوط والمسافات والظلال بالقيم المدققة.
4. صمم حالات default/hover/pressed/focus/disabled/error/success/loading عند انطباقها.
5. أنشئ نماذج للجوال واللوحي وسطح المكتب والعرض الكبير.
6. اختبر النص العربي الحقيقي والطول الزائد وRTL.
7. لا تعتبر الحقول المعلّمة `NOT PUBLISHED BY OFFICIAL SOURCE` خصائص رسمية.
8. سلّم للمطور قائمة القالب والمكونات والقواعد والاستثناءات.

## 12. استخدام الحزمة مع وكيل ذكاء اصطناعي

إذا كان الوكيل يعمل داخل هذا المستودع، فسيقرأ `AGENTS.md` تلقائيًا عندما تدعم الأداة ذلك. ولزيادة الدقة، استخدم طلبًا مثل:

```text
أنشئ صفحة خدمة عربية وفق AGENTS.md.
ابدأ بتحديد القالب من uds-templates.json، ثم المكونات من
uds-components.json والقواعد من uds-rules.json. استخدم uds-tokens.css،
وشغّل مدقق الامتثال وأكمل Definition of Done. لا تخترع أي خاصية معلّمة
NOT PUBLISHED BY OFFICIAL SOURCE. اختم بتقرير Unified Platform Compliance.
```

إذا كانت نافذة السياق صغيرة، زوّد الوكيل أولًا بالمرجع السريع، ثم افتح له مداخل JSON المرتبطة بالمهمة فقط بدل تحميل الدليل الرئيسي كاملًا.

## 13. تشغيل المثال المرجعي

من جذر المشروع:

```bash
python3 -m http.server 8765
```

ثم افتح:

```text
http://127.0.0.1:8765/uds-validation-demo/
```

لمعاينة عرض هاتف بعرض 390 بكسل:

```text
http://127.0.0.1:8765/uds-validation-demo/responsive-preview.html
```

لإعادة فحص المثال:

```bash
python3 tools/uds-compliance/uds_compliance.py uds-validation-demo \
  --json-out uds-validation-demo/compliance-report.json \
  --text-out uds-validation-demo/compliance-report.txt
```

النتيجة المرجعية الحالية: 25 `PASS`، صفر `FAIL`، صفر `WARNING`، و144 `MANUAL REVIEW`.

## 14. صيانة وتحديث الملفات

### تحديث القواعد

عدّل جدول القواعد المدققة بعد التحقق من المصدر، ثم شغّل:

```bash
python3 tools/uds-compliance/build_rules.py
```

يقوم الأمر بإعادة إنشاء `uds-rules.json` وإعادة تنسيق ملف القواعد. لا تعدّل JSON وحده؛ سيتم استبدال تعديلاتك عند التوليد التالي.

### تحديث المكونات أو القوالب

التعريفات المصدرية موجودة في:

```text
tools/uds-compliance/build_catalogs.py
```

عدّلها بعد مراجعة المصدر الرسمي، ثم شغّل:

```bash
python3 tools/uds-compliance/build_catalogs.py
```

لا تعدّل `uds-components.json` أو `uds-templates.json` وحدهما لأنهما ملفان مولدان.

### تشغيل اختبارات السلامة

```bash
python3 tools/uds-compliance/test_uds_compliance.py
```

تتحقق الاختبارات من المدخلات الصحيحة والخاطئة، تفرد 169 قاعدة، اكتمال 50 مكونًا، اكتمال 19 قالبًا، وصحة مراجع القواعد بين السجلات.

### بعد صدور تحديث رسمي

1. أعد فحص الموقع والمصادر المباشرة.
2. حدّث `crawl_inventory.md` وتقرير التغطية.
3. حدّث تاريخ التحقق في السجلات والمولدات.
4. حدّث القواعد والمكونات والقوالب والقيم المتأثرة فقط.
5. شغّل المولدات والاختبارات والمدقق.
6. أضف التغيير إلى سجل الإصدارات في الدليل الرئيسي.

## 15. أخطاء شائعة يجب تجنبها

- استخدام المرجع السريع بدل المصدر المباشر لحسم تعارض.
- اعتبار `MANUAL REVIEW` فشلًا أو نجاحًا تلقائيًا.
- تعديل ملفات JSON المولدة دون تعديل مولداتها.
- اختراع prop أو class أو token رسمي غير منشور.
- إنشاء مكون مخصص قبل فحص سجل المكونات.
- استخدام Button للتنقل أو Link لتنفيذ إجراء.
- الاعتماد على قلب CSS بصريًا دون اختبار ترتيب DOM ولوحة المفاتيح في RTL.
- اعتبار نتيجة المدقق الساكن بديلًا عن قارئ الشاشة والاختبار البصري.
- إعلان `COMPLIANT` مع وجود اختبار يدوي إلزامي غير مكتمل.

## 16. صيغة التسليم المطلوبة

بعد أي تغيير UI استخدم:

```text
Unified Platform Compliance

Template:
<القالب الرسمي أو NEEDS-VERIFICATION>

Official Components Used:
<المكونات المستخدمة>

Applicable Rules:
<معرفات القواعد>

Automated Checks:
PASS / FAIL
<ملخص ومسار التقرير>

Manual Checks:
<ما تم فحصه وما بقي>

Known Exceptions:
<لا يوجد، أو الاستثناء والسبب والقواعد المتأثرة>

Overall:
COMPLIANT | PARTIALLY COMPLIANT | NON-COMPLIANT
```

استخدم `COMPLIANT` فقط بعد اجتياز القواعد الإلزامية والاختبارات البشرية المنطبقة. استخدم `PARTIALLY COMPLIANT` عند عدم وجود مخالفة مع بقاء مراجعات بشرية، و`NON-COMPLIANT` عند فشل قاعدة إلزامية منطبقة.
