# Official resources snapshot

هذه نسخة محلية مؤرخة من الموارد العامة التي كشفها موقع **كود المنصات** أثناء المراجعة. الغرض منها التحقق والتتبع، لا إعادة النشر ولا استبدال المصدر الحي.

- **Base source:** <https://design.dga.gov.sa/>
- **Last verified:** 2026-09-07
- **Retrieval:** HTTP GET مباشر للملفات العامة التي أعلنها الموقع.
- **Scope:** غلاف التطبيق، ملفا البناء الفعليان، ملفات الاكتشاف العامة، وأصلان بصريان معلنان في رأس الصفحة.

## المحتويات

| الملف | المصدر | النوع الحقيقي | الاستخدام | الملاحظة |
|---|---|---|---|---|
| `site-assets/index.html` | <https://design.dga.gov.sa/> | HTML | مراجعة metadata وروابط ملفات البناء | غلاف تطبيق React؛ المحتوى الفعلي يُحمّل عبر JavaScript. |
| `site-assets/index-PDaQ7SHU.css` | <https://design.dga.gov.sa/assets/index-PDaQ7SHU.css> | CSS | التحقق من المتغيرات والقيم البصرية المنشورة | اسم الملف ذو بصمة وقد يتغير في إصدار لاحق. |
| `site-assets/index-cnrvMddo.js` | <https://design.dga.gov.sa/assets/index-cnrvMddo.js> | JavaScript bundle | التحقق من المسارات والنصوص والواجهات المنشورة | ملف بناء مصغّر، وليس API موثّقًا للمستهلك. |
| `site-assets/sitemap.xml` | <https://design.dga.gov.sa/sitemap.xml> | XML | اكتشاف الصفحات | يحوي 78 رابطًا فقط، بينما أظهر التنقل الحي 96 مسارًا؛ لا يُعد كاملًا. |
| `site-assets/robots.txt` | <https://design.dga.gov.sa/robots.txt> | Text | مراجعة الاكتشاف العام | يحتوي رابط Sitemap تجريبيًا إلى `yourdomain.com`؛ موثق كتعارض مصدر. |
| `site-assets/rss.xml` | <https://design.dga.gov.sa/rss.xml> | XML | مراجعة موجز المقالات | مورد صالح. |
| `site-assets/favicon.svg` | <https://design.dga.gov.sa/favicon.svg> | SVG | أصل الهوية الصغير المعلن في `<head>` | لا يُعامل كشعار منصة إلزامي. |
| `site-assets/og-image.jpeg` | <https://design.dga.gov.sa/og-image.jpeg> | JPEG، ‏1600×960 | صورة المشاركة المعلنة في Open Graph/Twitter | مثال من موقع التوثيق، لا قالبًا حكوميًا عامًا. |
| `site-assets/critical.css` | <https://design.dga.gov.sa/critical.css> | **HTML وليس CSS** | إثبات سلوك المسار | `⚠️ SOURCE CONFLICT`: أعاد غلاف التطبيق بدل ملف CSS. لا تستخدمه كتنسيق. |
| `site-assets/non-critical.js` | <https://design.dga.gov.sa/non-critical.js> | **HTML وليس JavaScript** | إثبات سلوك المسار | `⚠️ SOURCE CONFLICT`: أعاد غلاف التطبيق بدل JavaScript. لا تشغّله. |
| `site-assets/sitemap_index.xml` | <https://design.dga.gov.sa/sitemap_index.xml> | **HTML وليس XML** | إثبات سلوك المسار | `⚠️ SOURCE CONFLICT`: مسار fallback وليس فهرس Sitemap صالحًا. |

## موارد رسمية خارجية مرتبطة

لم تُنسخ موارد Figma محليًا لأن صفحات Community وخدماتها تُدار خارجيًا وقد تتطلب جلسة مستخدم أو شروط ترخيص مستقلة. الروابط التي كشفها الموقع وجرى التحقق من وجودها:

- [حساب هيئة الحكومة الرقمية على Figma](https://www.figma.com/@sdga)
- [Foundations — Platforms Code](https://www.figma.com/community/file/1392267405633663431/foundations-platforms-code)
- [Icons — Platforms Code](https://www.figma.com/community/file/1392269191144731080/icons-platforms-code)
- [Desktop Components Library](https://www.figma.com/community/file/1392264328585493958/components-library-platforms-code)
- [Mobile Components Library](https://www.figma.com/community/file/1392271796654597578/mobile-components-platforms-code)
- [IBM Plex Sans](https://fonts.google.com/specimen/IBM+Plex+Sans)
- [الخط السعودي — وزارة الثقافة](https://engage.moc.gov.sa/e/fonts/saudi-font/?lang=ar)

## طريقة الاستخدام

1. اعتمد الدليل الرئيسي والقواعد المنظمة في جذر المشروع للتنفيذ.
2. ارجع إلى CSS للتحقق من قيمة منشورة، ولا تعتمد أسماء الأصناف المصغّرة أو بنية bundle كواجهة مستقرة.
3. افحص المصدر الحي قبل مشروع جديد لأن أسماء ملفات البناء والموارد الخارجية قابلة للتغيير.
4. لا تستخدم ملفات fallback الثلاثة على أنها CSS/JS/XML؛ احتُفظ بها فقط لأغراض الإثبات.

## ما لم يوجد

- لم يكشف DOM العام عن PDF أو ZIP أو Starter Kit مباشر.
- Storybook وGitHub معروضان على الموقع بعبارة «قريبًا» من دون رابط رسمي قابل للاستخدام وقت التحقق.
- لا يوجد مصدر رسمي يثبت دعم Angular أو Vue أو Web Components؛ التثبيت المنشور يخص حزمة React فقط.
