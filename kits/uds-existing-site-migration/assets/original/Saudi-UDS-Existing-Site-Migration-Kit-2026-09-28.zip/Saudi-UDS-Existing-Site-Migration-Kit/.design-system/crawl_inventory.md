# Crawl Inventory — Saudi Unified Platform Code

Last verified: 2026-09-07 (Asia/Riyadh)

Discovery baseline: live navigation, site-wide navigation DOM, `/sitemap`, `/sitemap.xml`, `/robots.txt`, and the published CSS/JavaScript bundles. The live navigation exposed 96 unique internal routes. The XML sitemap is incomplete and `robots.txt` points to the placeholder domain `yourdomain.com`; therefore the live navigation list is the authoritative crawl queue for this pass.

| # | URL | Title | Section | Route Type | Status | Links | Images | Processed | Notes |
|---:|---|---|---|---|---|---:|---:|---|---|
| 1 | https://design.dga.gov.sa/ | نظام التصميم الموحد للمملكة العربية السعودية | General | CONTENT_PAGE | Read | 13 | 1 | Yes | DOM text, headings, links, controls and assets captured |
| 2 | https://design.dga.gov.sa/designing | ابدأ التصميم | Design | GUIDELINE | Read | 14 | 8 | Yes | DOM text, headings, links, controls and assets captured |
| 3 | https://design.dga.gov.sa/designing-for-mobile | ابدأ التصميم للأجهزة المحمولة | Design | GUIDELINE | Read | 13 | 2 | Yes | DOM text, headings, links, controls and assets captured |
| 4 | https://design.dga.gov.sa/design-installation | إدراج مكتبات نظام التصميم | Design | GUIDELINE | Read | 12 | 22 | Yes | DOM text, headings, links, controls and assets captured |
| 5 | https://design.dga.gov.sa/migration-guide | دليل ترحيل المكتبة | Design | GUIDELINE | Read | 16 | 9 | Yes | DOM text, headings, links, controls and assets captured |
| 6 | https://design.dga.gov.sa/developing | ابدأ التطوير | Development | GUIDELINE | Read | 12 | 6 | Yes | DOM text, headings, links, controls and assets captured |
| 7 | https://design.dga.gov.sa/contributing | ابدأ بالمساهمة | Development | GUIDELINE | Read | 12 | 0 | Yes | DOM text, headings, links, controls and assets captured |
| 8 | https://design.dga.gov.sa/guidelines | الإرشادات | General | GUIDELINE | Read | 12 | 0 | Yes | DOM text, headings, links, controls and assets captured |
| 9 | https://design.dga.gov.sa/guidelines/foundations/color-system | الألوان | Foundations | GUIDELINE | Read | 13 | 19 | Yes | DOM text, headings, links, controls and assets captured |
| 10 | https://design.dga.gov.sa/guidelines/foundations/elevation | الظلال | Foundations | GUIDELINE | Read | 11 | 14 | Yes | DOM text, headings, links, controls and assets captured |
| 11 | https://design.dga.gov.sa/guidelines/foundations/iconography | الأيقونات | Foundations | GUIDELINE | Read | 11 | 17 | Yes | DOM text, headings, links, controls and assets captured |
| 12 | https://design.dga.gov.sa/guidelines/foundations/layout-and-spacing | تخطيط وتباعد | Foundations | GUIDELINE | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 13 | https://design.dga.gov.sa/guidelines/foundations/typography | الطباعة - الخط | Foundations | GUIDELINE | Read | 11 | 20 | Yes | DOM text, headings, links, controls and assets captured |
| 14 | https://design.dga.gov.sa/guidelines/templates | القوالب | Templates | GUIDELINE | Read | 15 | 18 | Yes | DOM text, headings, links, controls and assets captured |
| 15 | https://design.dga.gov.sa/guidelines/templates/hajj-template | قالب الحج 2026 | Templates | TEMPLATE | Read | 12 | 9 | Yes | DOM text, headings, links, controls and assets captured |
| 16 | https://design.dga.gov.sa/guidelines/templates/founding-day | قالب يوم التأسيس 2026 م | Templates | TEMPLATE | Read | 11 | 11 | Yes | DOM text, headings, links, controls and assets captured |
| 17 | https://design.dga.gov.sa/guidelines/templates/national-day | قالب اليوم الوطني 95 | Templates | TEMPLATE | Read | 11 | 9 | Yes | DOM text, headings, links, controls and assets captured |
| 18 | https://design.dga.gov.sa/guidelines/templates/home-page | قالب الصفحة الرئيسية | Templates | TEMPLATE | Read | 11 | 13 | Yes | DOM text, headings, links, controls and assets captured |
| 19 | https://design.dga.gov.sa/guidelines/templates/contact-us-page | قالب صفحة التواصل | Templates | TEMPLATE | Read | 11 | 9 | Yes | DOM text, headings, links, controls and assets captured |
| 20 | https://design.dga.gov.sa/guidelines/templates/form-page | قالب صفحة النموذج | Templates | TEMPLATE | Read | 11 | 9 | Yes | DOM text, headings, links, controls and assets captured |
| 21 | https://design.dga.gov.sa/guidelines/templates/help-page | قالب مركز المساعدة | Templates | TEMPLATE | Read | 11 | 9 | Yes | DOM text, headings, links, controls and assets captured |
| 22 | https://design.dga.gov.sa/guidelines/templates/feedback-section | قالب التعليقات | Templates | TEMPLATE | Read | 11 | 4 | Yes | DOM text, headings, links, controls and assets captured |
| 23 | https://design.dga.gov.sa/guidelines/templates/service-page | صفحة الخدمة | Templates | TEMPLATE | Read | 11 | 9 | Yes | DOM text, headings, links, controls and assets captured |
| 24 | https://design.dga.gov.sa/guidelines/templates/faqs-page | صفحة الأسئلة الشائعة | Templates | TEMPLATE | Read | 11 | 15 | Yes | DOM text, headings, links, controls and assets captured |
| 25 | https://design.dga.gov.sa/guidelines/templates/sitemap-page | صفحة خريطة الموقع | Templates | TEMPLATE | Read | 11 | 10 | Yes | DOM text, headings, links, controls and assets captured |
| 26 | https://design.dga.gov.sa/guidelines/templates/page-not-found | صفحة الخطأ | Templates | TEMPLATE | Read | 11 | 9 | Yes | DOM text, headings, links, controls and assets captured |
| 27 | https://design.dga.gov.sa/guidelines/templates/search-page | صفحة البحث | Templates | TEMPLATE | Read | 11 | 16 | Yes | DOM text, headings, links, controls and assets captured |
| 28 | https://design.dga.gov.sa/guidelines/templates/e-participation-page | صفحة المشاركة الإلكترونية | Templates | TEMPLATE | Read | 11 | 13 | Yes | DOM text, headings, links, controls and assets captured |
| 29 | https://design.dga.gov.sa/guidelines/templates/about-page | حول الكيان | Templates | TEMPLATE | Read | 21 | 10 | Yes | DOM text, headings, links, controls and assets captured |
| 30 | https://design.dga.gov.sa/guidelines/templates/content-page | صفحة المحتوى | Templates | TEMPLATE | Read | 11 | 11 | Yes | DOM text, headings, links, controls and assets captured |
| 31 | https://design.dga.gov.sa/guidelines/templates/cookies-banner | لافتة ملفات تعريف الارتباط | Templates | TEMPLATE | Read | 11 | 4 | Yes | DOM text, headings, links, controls and assets captured |
| 32 | https://design.dga.gov.sa/guidelines/templates/chatbot | روبوت الدردشة | Templates | TEMPLATE | Read | 11 | 5 | Yes | DOM text, headings, links, controls and assets captured |
| 33 | https://design.dga.gov.sa/guidelines/templates/rating-section | قسم التقييم | Templates | TEMPLATE | Read | 11 | 4 | Yes | DOM text, headings, links, controls and assets captured |
| 34 | https://design.dga.gov.sa/guidelines/components/actions/buttons | الأزرار | Components | COMPONENT | Read | 11 | 15 | Yes | DOM text, headings, links, controls and assets captured |
| 35 | https://design.dga.gov.sa/guidelines/components/actions/floating-Button | الزر العائم | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 36 | https://design.dga.gov.sa/guidelines/components/actions/dropdown | القائمة المنسدلة | Components | COMPONENT | Read | 11 | 4 | Yes | DOM text, headings, links, controls and assets captured |
| 37 | https://design.dga.gov.sa/guidelines/components/actions/link | الرابط | Components | COMPONENT | Read | 12 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 38 | https://design.dga.gov.sa/guidelines/components/actions/chip | العلامات التفاعلية | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 39 | https://design.dga.gov.sa/guidelines/components/content-display/accordion | أكورديون | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 40 | https://design.dga.gov.sa/guidelines/components/content-display/card | البطاقة | Components | COMPONENT | Read | 11 | 7 | Yes | DOM text, headings, links, controls and assets captured |
| 41 | https://design.dga.gov.sa/guidelines/components/content-display/carousel | عنصر التمرير | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 42 | https://design.dga.gov.sa/guidelines/components/content-display/list | قائمة التعداد | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 43 | https://design.dga.gov.sa/guidelines/components/content-display/code-snippet | مستعرض الكود | Components | COMPONENT | Read | 16 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 44 | https://design.dga.gov.sa/guidelines/components/content-display/quote | الاقتباس | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 45 | https://design.dga.gov.sa/guidelines/components/content-display/divider | الخط الفاصل | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 46 | https://design.dga.gov.sa/guidelines/components/content-display/digital-stamp | الختم الرقمي | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 47 | https://design.dga.gov.sa/guidelines/components/data-display/avatar | الصورة الرمزية | Components | COMPONENT | Read | 11 | 5 | Yes | DOM text, headings, links, controls and assets captured |
| 48 | https://design.dga.gov.sa/guidelines/components/data-display/metric | بطاقة المؤشرات | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 49 | https://design.dga.gov.sa/guidelines/components/data-display/table | الجدول | Components | COMPONENT | Read | 11 | 4 | Yes | DOM text, headings, links, controls and assets captured |
| 50 | https://design.dga.gov.sa/guidelines/components/data-display/content-switcher | مُبدّل المحتوى | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 51 | https://design.dga.gov.sa/guidelines/components/data-display/charts | الرسوم البيانية | Components | COMPONENT | Read | 11 | 9 | Yes | DOM text, headings, links, controls and assets captured |
| 52 | https://design.dga.gov.sa/guidelines/components/data-display/structured-list | القائمة المنظَّمة | Components | COMPONENT | Read | 11 | 4 | Yes | DOM text, headings, links, controls and assets captured |
| 53 | https://design.dga.gov.sa/guidelines/components/feedback/notification | الإشعارات | Components | COMPONENT | Read | 11 | 11 | Yes | DOM text, headings, links, controls and assets captured |
| 54 | https://design.dga.gov.sa/guidelines/components/feedback/modal | النوافذ المنبثقة | Components | COMPONENT | Read | 11 | 2 | Yes | DOM text, headings, links, controls and assets captured |
| 55 | https://design.dga.gov.sa/guidelines/components/feedback/tooltip | التلميح | Components | COMPONENT | Read | 11 | 4 | Yes | DOM text, headings, links, controls and assets captured |
| 56 | https://design.dga.gov.sa/guidelines/components/feedback/rating | التقييم | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 57 | https://design.dga.gov.sa/guidelines/components/forms-and-inputs/checkbox | مربع الاختيار | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 58 | https://design.dga.gov.sa/guidelines/components/forms-and-inputs/datepicker | محدد التاريخ | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 59 | https://design.dga.gov.sa/guidelines/components/forms-and-inputs/input | المدخلات | Components | COMPONENT | Read | 11 | 5 | Yes | DOM text, headings, links, controls and assets captured |
| 60 | https://design.dga.gov.sa/guidelines/components/forms-and-inputs/file-uploader | رفع الملفات | Components | COMPONENT | Read | 11 | 6 | Yes | DOM text, headings, links, controls and assets captured |
| 61 | https://design.dga.gov.sa/guidelines/components/forms-and-inputs/radio | زر الاختيار | Components | COMPONENT | Read | 11 | 4 | Yes | DOM text, headings, links, controls and assets captured |
| 62 | https://design.dga.gov.sa/guidelines/components/forms-and-inputs/slider | شريط التمرير | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 63 | https://design.dga.gov.sa/guidelines/components/forms-and-inputs/steps | الخطوات | Components | COMPONENT | Read | 11 | 5 | Yes | DOM text, headings, links, controls and assets captured |
| 64 | https://design.dga.gov.sa/guidelines/components/forms-and-inputs/switch | زر التبديل | Components | COMPONENT | Read | 11 | 7 | Yes | DOM text, headings, links, controls and assets captured |
| 65 | https://design.dga.gov.sa/guidelines/components/forms-and-inputs/textarea | منطقة النص | Components | COMPONENT | Read | 11 | 5 | Yes | DOM text, headings, links, controls and assets captured |
| 66 | https://design.dga.gov.sa/guidelines/components/forms-and-inputs/number-input | مدخلات الأرقام | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 67 | https://design.dga.gov.sa/guidelines/components/loading-and-status/loading | جاري التحميل | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 68 | https://design.dga.gov.sa/guidelines/components/loading-and-status/progress-bar | شريط التقدم | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 69 | https://design.dga.gov.sa/guidelines/components/loading-and-status/radial-stepper | شريط التقدم الدائري | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 70 | https://design.dga.gov.sa/guidelines/components/loading-and-status/skeleton | الهياكل | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 71 | https://design.dga.gov.sa/guidelines/components/navigational/breadcrumbs | مسار التصفح | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 72 | https://design.dga.gov.sa/guidelines/components/navigational/menu | القائمة | Components | COMPONENT | Read | 11 | 4 | Yes | DOM text, headings, links, controls and assets captured |
| 73 | https://design.dga.gov.sa/guidelines/components/navigational/pagination | ترقيم الصفحات | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 74 | https://design.dga.gov.sa/guidelines/components/navigational/tabs | قائمة علامات التبويب | Components | COMPONENT | Read | 15 | 5 | Yes | DOM text, headings, links, controls and assets captured |
| 75 | https://design.dga.gov.sa/guidelines/components/navigational/slide-out | القائمة الجانبية المنسدلة | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 76 | https://design.dga.gov.sa/guidelines/components/search-and-filters/search-box | حقل البحث | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 77 | https://design.dga.gov.sa/guidelines/components/search-and-filters/tags | العلامات | Components | COMPONENT | Read | 11 | 11 | Yes | DOM text, headings, links, controls and assets captured |
| 78 | https://design.dga.gov.sa/guidelines/components/search-and-filters/filtration | التصفية | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 79 | https://design.dga.gov.sa/guidelines/components/ui-shell/navigation-header | شريط التنقل العلوي | Components | COMPONENT | Read | 16 | 9 | Yes | DOM text, headings, links, controls and assets captured |
| 80 | https://design.dga.gov.sa/guidelines/components/ui-shell/navigation-drawer | قائمة التنقل الجانبية | Components | COMPONENT | Read | 22 | 4 | Yes | DOM text, headings, links, controls and assets captured |
| 81 | https://design.dga.gov.sa/guidelines/components/ui-shell/table-of-content | جدول المحتويات | Components | COMPONENT | Read | 11 | 5 | Yes | DOM text, headings, links, controls and assets captured |
| 82 | https://design.dga.gov.sa/guidelines/components/ui-shell/second-nav-header | شريط التنقل الثانوي | Components | COMPONENT | Read | 11 | 3 | Yes | DOM text, headings, links, controls and assets captured |
| 83 | https://design.dga.gov.sa/guidelines/components/ui-shell/footer | التذييل | Components | COMPONENT | Read | 36 | 5 | Yes | DOM text, headings, links, controls and assets captured |
| 84 | https://design.dga.gov.sa/thoughts | الرؤى والابتكارات | Articles | CONTENT_PAGE | Read | 12 | 0 | Yes | DOM text, headings, links, controls and assets captured |
| 85 | https://design.dga.gov.sa/thoughts/atomic-design | التصميم الذري | Articles | CONTENT_PAGE | Read | 12 | 1 | Yes | DOM text, headings, links, controls and assets captured |
| 86 | https://design.dga.gov.sa/thoughts/responsive-design | التصميم المتجاوب | Articles | CONTENT_PAGE | Read | 12 | 2 | Yes | DOM text, headings, links, controls and assets captured |
| 87 | https://design.dga.gov.sa/thoughts/AccessibilityEase | إمكانية الوصول | Articles | CONTENT_PAGE | Read | 12 | 0 | Yes | DOM text, headings, links, controls and assets captured |
| 88 | https://design.dga.gov.sa/thoughts/designToken | رموز التصميم | Articles | CONTENT_PAGE | Read | 12 | 11 | Yes | DOM text, headings, links, controls and assets captured |
| 89 | https://design.dga.gov.sa/thoughts/localAndGlobal | المعايير المحلية والعالمية | Articles | CONTENT_PAGE | Read | 12 | 0 | Yes | DOM text, headings, links, controls and assets captured |
| 90 | https://design.dga.gov.sa/thoughts/consistency-and-unified-identity | الاتساق والهوية الموحدة | Articles | CONTENT_PAGE | Read | 12 | 2 | Yes | DOM text, headings, links, controls and assets captured |
| 91 | https://design.dga.gov.sa/support | هل تحتاج إلى مساعدة؟ نحن هنا لمساعدتك! | General | CONTENT_PAGE | Read | 27 | 0 | Yes | DOM text, headings, links, controls and assets captured |
| 92 | https://design.dga.gov.sa/about-platforms-code | كود المنصات | General | CONTENT_PAGE | Read | 12 | 2 | Yes | DOM text, headings, links, controls and assets captured |
| 93 | https://design.dga.gov.sa/updates/roadmap | الجدول الزمني للتطوير | Updates | CONTENT_PAGE | Read | 12 | 0 | Yes | DOM text, headings, links, controls and assets captured |
| 94 | https://design.dga.gov.sa/updates/change-log | سجل التحديثات | Updates | CONTENT_PAGE | Read | 16 | 0 | Yes | DOM text, headings, links, controls and assets captured |
| 95 | https://design.dga.gov.sa/AssessmentCriteria | معايير التقييم | General | GUIDELINE | Read | 22 | 32 | Yes | DOM text, headings, links, controls and assets captured |
| 96 | https://design.dga.gov.sa/sitemap | خريطة الموقع | General | TECHNICAL_ROUTE | Read | 92 | 0 | Yes | DOM text, headings, links, controls and assets captured |

## Discovery and resource records

| URL | Type | Status | Notes |
|---|---|---|---|
| https://design.dga.gov.sa/robots.txt | robots | Read | Valid file, but its Sitemap directive incorrectly targets `https://yourdomain.com/sitemap.xml`. |
| https://design.dga.gov.sa/sitemap.xml | XML sitemap | Read | Public and readable, but incomplete compared with live navigation (78 URLs versus 96). |
| https://design.dga.gov.sa/sitemap_index.xml | HTML fallback | Read | Not an XML sitemap index; server returns the application shell. |
| https://design.dga.gov.sa/rss.xml | RSS | Read | Public RSS feed for articles. |
| https://design.dga.gov.sa/assets/index-PDaQ7SHU.css | CSS bundle | Downloaded and inspected | Published style bundle; retained in `official-resources/site-assets/`. |
| https://design.dga.gov.sa/assets/index-cnrvMddo.js | JavaScript bundle | Downloaded and inspected | Published application bundle; retained in `official-resources/site-assets/`. |
| https://design.dga.gov.sa/critical.css | HTML fallback | Read | Link exists in the shell, but endpoint returns the application HTML rather than CSS. |
| https://design.dga.gov.sa/non-critical.js | HTML fallback | Read | Script URL returns the application HTML rather than JavaScript. |
| https://design.dga.gov.sa/favicon.svg | SVG | Downloaded and inspected | Official favicon referenced by the application shell; retained in `official-resources/site-assets/`. |
| https://design.dga.gov.sa/og-image.jpeg | JPEG (1600×960) | Downloaded and inspected | Open Graph/Twitter preview asset referenced by the application shell. |

## Crawl totals

| Metric | Count |
|---|---:|
| Unique live-navigation routes | 96 |
| Routes read successfully | 96 |
| Foundation pages | 5 |
| Template entries | 19 |
| Template section pages including index | 20 |
| Component pages | 50 |
| Article pages including index | 7 |
| `/guidelines` routes including index | 76 |
| Locally retained site asset responses | 11 |

## URL classification and unique-content count

| Route Type | Count | Unique rendered subjects | Notes |
|---|---:|---:|---|
| CONTENT_PAGE | 12 | 12 | Home, support/about, articles, and updates. |
| COMPONENT | 50 | 50 | One public subject page per official component. |
| TEMPLATE | 19 | 19 | Excludes the templates section index. |
| GUIDELINE | 14 | 14 | Foundations, design/development, assessment, and two section indexes. |
| TECHNICAL_ROUTE | 1 | 1 | Human-readable `/sitemap` page. |
| RESOURCE | 0 | 0 | Binary/discovery resources are listed separately below the 96-page table. |
| REDIRECT | 0 | 0 | No discovered route ended on a different final URL. |
| ALIAS | 0 | 0 | No duplicate final route or duplicate primary H1 was found. |
| LANGUAGE_VARIANT | 0 | 0 | No separate language route was exposed. |
| OTHER | 0 | 0 | — |
| **Total** | **96** | **96** | 96 unique requested URLs, 96 unique final URLs, and 96 unique primary H1 headings. |

The unique-content count uses the canonical final URL plus the first non-empty H1. Shared navigation/footer text is not counted as duplicate content. The application-wide HTML `<title>` is the same on all routes and therefore is not a reliable uniqueness signal.

No public route in the live-navigation queue failed to render. The Figma community resources were verified as external links/titles, but their managed design-file contents were not copied into this workspace. No direct public PDF, ZIP, DOCX, XLSX, JSON token file, GitHub repository, or usable Storybook link was exposed by the rendered site during this pass.
