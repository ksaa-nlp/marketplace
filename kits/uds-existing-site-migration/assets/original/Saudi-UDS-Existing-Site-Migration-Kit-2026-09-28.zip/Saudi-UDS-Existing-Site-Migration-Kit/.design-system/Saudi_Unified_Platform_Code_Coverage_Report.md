# Saudi Unified Platform Code — Coverage Report

> **Final verification date:** 2026-09-07 (Asia/Riyadh)  
> **Start URL:** <https://design.dga.gov.sa/>  
> **Coverage baseline:** live site navigation and rendered DOM, cross-checked with `/sitemap`, `sitemap.xml`, `robots.txt`, RSS, build assets, footer/internal links, and external resource cards.

## Executive result

| Metric | Result | Coverage |
|---|---:|---:|
| Public internal routes discovered from live navigation | 96 | baseline |
| Public internal routes rendered and processed | 96 | **100%** |
| Failed internal route renders | 0 | 0% |
| `/guidelines` routes processed | 76/76 | **100%** |
| Foundation pages | 5/5 | **100%** |
| Component pages | 50/50 | **100%** |
| Template entries | 19/19 | **100%** |
| Template pages including section index | 20/20 | **100%** |
| Article pages including section index | 7/7 | **100%** |
| Locally retained official site responses/assets | 11 | 8 usable + 3 HTML fallbacks |
| Atomic rules extracted | 169 | unique IDs |
| Required master-guide numbered sections | 32/32 | **100%** |

**Conclusion:** all public routes exposed by the live navigation were opened and read. This is 100% coverage of the discovered public route baseline, not a claim that unpublished, authenticated, or externally managed design-file contents were obtained.

## Phase 2 verification and enforcement result

| Verification area | Result | Evidence |
|---|---:|---|
| Truly unique public content subjects | **96** | 96 unique normalized final URLs and 96 unique non-empty first `h1` values. The shared HTML `<title>` is an application-shell title and was not used as the content-identity key. |
| Atomic rules audited | **169/169** | Unique IDs, direct source URLs, source page titles, verification dates, implementation notes, and testability classifications. |
| Rule testability | **25 / 100 / 44** | `AUTOMATED` / `SEMI_AUTOMATED` / `MANUAL`; totals 169. |
| Exact duplicate IDs | **0** | Registry build rejects duplicate IDs. |
| Exact duplicate normalized rule text | **0** | Text-normalization audit found no identical rules. |
| Component registry | **50/50** | Exhaustive machine-readable schema; unpublished official fields carry the exact marker `NOT PUBLISHED BY OFFICIAL SOURCE`. |
| Template registry | **19/19** | Machine-readable hierarchy, sections, components, states of publication, rules, and direct sources. |
| Compliance checker and registry unit tests | **5/5 PASS** | Passing fixture, failing fixture, traceable rules, component schema, and template schema. |
| Validation demo static checks | **25 PASS, 0 FAIL, 0 WARNING** | 144 rules remain `MANUAL REVIEW`, reflecting their classification rather than a violation. |
| Runtime browser audit | **PASS within recorded scope** | Desktop and 390×844 mobile reflow, RTL accessibility tree, search input, and radio checked-state verified. |

The audited rule table is [`Saudi_Unified_Platform_Code_Rules.md`](./Saudi_Unified_Platform_Code_Rules.md); the enforcement registry is [`uds-rules.json`](./uds-rules.json). Known semantic overlap is retained when two rules cover different scopes; the audit did not merge distinct requirements merely because they share a topic.

## URL classification

| Route type | Count |
|---|---:|
| `COMPONENT` | 50 |
| `TEMPLATE` | 19 |
| `GUIDELINE` | 14 |
| `CONTENT_PAGE` | 12 |
| `TECHNICAL_ROUTE` | 1 |
| `RESOURCE`, `REDIRECT`, `ALIAS`, `LANGUAGE_VARIANT`, `OTHER` | 0 |
| **Total classified page routes** | **96** |

Non-page responses and external design resources are accounted for separately in Resource coverage. The route-by-route classification appears in [`crawl_inventory.md`](./crawl_inventory.md).

## Coverage by site area

| Area | Discovered | Processed | Included in deliverables | Notes |
|---|---:|---:|---|---|
| General/home/support/about/assessment/sitemap | 6 | 6 | نعم | Includes mandatory/recommended assessment criteria. |
| Design and migration | 4 | 4 | نعم | Design start, mobile, library installation, migration. |
| Development/contribution | 2 | 2 | نعم | React install captured; GitHub/Storybook unavailable. |
| Guidelines index | 1 | 1 | نعم | Entry page. |
| Foundations | 5 | 5 | نعم | Color, elevation, iconography, layout/spacing, typography. |
| Templates | 20 | 20 | نعم | One index + 19 documented template entries. |
| Components | 50 | 50 | نعم | Eight component categories. |
| Thoughts/articles | 7 | 7 | نعم | One index + six articles. |
| Updates | 2 | 2 | نعم | Roadmap and change log. |
| **Total** | **96** | **96** | **نعم** | Matches live-navigation inventory. |

## Component coverage

| Category | Pages | Documented |
|---|---:|---:|
| Actions | 5 | 5 |
| Content display | 8 | 8 |
| Data display | 6 | 6 |
| Feedback | 4 | 4 |
| Forms and inputs | 10 | 10 |
| Loading and status | 4 | 4 |
| Navigational | 5 | 5 |
| Search and filters | 3 | 3 |
| UI shell | 5 | 5 |
| **Total** | **50** | **50** |

Every component has purpose/selection guidance, anatomy/variants/states, hover/focus/active/disabled/error/success/loading, RTL/responsive behavior, accessibility/keyboard/ARIA, content, tokens, do/don't, code-example status, rule mapping, direct source, page title, and verification date in [`uds-components.json`](./uds-components.json). When a field was not officially published, the registry uses exactly `NOT PUBLISHED BY OFFICIAL SOURCE` rather than supplying a guessed value.

## Template coverage

All 19 entries were processed: Hajj, Founding Day, National Day, Home, Contact, Form, Help, Feedback, Service, FAQs, Sitemap, Page Not Found, Search, E-Participation, About, Content, Cookie Banner, Chatbot, and Rating Section.

Each template has a stable ID plus use case, published/required/optional sections, component hierarchy, required/optional components, layout regions, header/navigation/hero/main/CTA/footer behavior, responsive/RTL/accessibility/content rules, rule IDs, source URLs, source page title, and verification date in [`uds-templates.json`](./uds-templates.json).

No public Dashboard, Login, or Authentication template was exposed. Dashboard composition is marked `INFERRED`; Login/Authentication remains `⚠️ NEEDS VERIFICATION`.

## Resource coverage

| Resource class | Found | Retained/read | Result |
|---|---:|---:|---|
| Application HTML shell | 1 | 1 | usable |
| Hashed CSS bundle | 1 | 1 | usable; tokens inspected |
| Hashed JavaScript bundle | 1 | 1 | usable; routes/text/assets inspected |
| Sitemap XML | 1 | 1 | usable but incomplete |
| Robots | 1 | 1 | readable; bad placeholder directive |
| RSS | 1 | 1 | usable |
| Favicon SVG | 1 | 1 | usable |
| OG image | 1 | 1 | usable, 1600×960 |
| Declared `critical.css` | 1 | 1 | HTML fallback; unusable as CSS |
| Declared `non-critical.js` | 1 | 1 | HTML fallback; unusable as JS |
| `sitemap_index.xml` | 1 | 1 | HTML fallback; unusable as XML |
| Direct PDF/ZIP/DOCX/XLSX/token JSON | 0 | 0 | not exposed |
| GitHub repository | 0 | 0 | site says “coming soon” |
| Storybook | 0 | 0 | site says “coming soon” |
| External Figma libraries | 4 | link/title verified | not copied locally |

Local resource documentation: [`official-resources/README.md`](../official-resources/README.md).

## Pages or files that could not be fully opened

- **Internal public pages:** none; 96/96 rendered.
- **Figma managed file contents:** external community page titles/links were verified, but layers/variables/files were not exported. They may require Figma-specific sessions or licensing. This limits verification of exact component API/variant property names, not the public website guidance.
- **GitHub/Storybook:** no usable official links existed; marked “coming soon”.
- **Fallback responses:** `critical.css`, `non-critical.js`, and `sitemap_index.xml` opened but contained the app HTML instead of their declared resource types.

## Broken or conflicting discovery signals

1. `⚠️ SOURCE CONFLICT` `sitemap.xml` contains 78 URLs while the live navigation exposed 96.
2. `⚠️ SOURCE CONFLICT` `robots.txt` points to `https://yourdomain.com/sitemap.xml`.
3. `⚠️ SOURCE CONFLICT` three declared asset/discovery paths return HTML fallback.
4. `⚠️ SOURCE CONFLICT` layout table pairs `width-xs: 34rem / 384px` and `paragraph-max-width: 20rem / 720px`; pairs are not mathematically equivalent. CSS/pixel value 720px is retained with a warning.
5. `⚠️ SOURCE CONFLICT` Card accessibility text refers to Accordion, and Button accessibility text contains Notification-specific live-region roles. These copy defects were excluded from component rules.

## Content needing additional verification

- Public component API, prop names, import statements, and stable CSS-variable namespace.
- Storybook and GitHub URLs/releases.
- Motion durations/easing and z-index tokens.
- A unified official convention for Arabic/Latin mixed text, numbers, dates, phone numbers, email, and URLs.
- Exact sticky header/login/user-menu requirements.
- Required legal/footer links per individual government entity.
- Current applicability of the time-bound 2026 campaign/AI-year guidance.
- Figma-internal variables, variants, and downloadable licensing conditions.

## Final Verification Pass

| Check | Result | Evidence |
|---|---|---|
| Re-open site map and compare discovered vs processed | PASS | 96 discovered = 96 processed; XML discrepancy documented. |
| Review all major areas | PASS | General, design, development, foundations, templates, components, articles, updates. |
| All components documented | PASS | 50 numbered Component headings in Master Guide. |
| All templates documented | PASS | 19 template rows and selection matrix. |
| Source links present | PASS | Every atomic rule has a Source; every component has a direct URL. |
| Official vs inferred separated | PASS | Four levels defined; all inferred rules carry `INFERRED`. |
| AI-agent usability | PASS | Workflow, decision rules, chooser, template matrix, and checklists exist. |
| Exact required master structure | PASS | 32/32 numbered level-2 sections. |
| Unique machine-readable rules | PASS | 169 unique rule rows; duplicate-ID check required zero duplicates. |
| Resources documented | PASS | 11 local responses/assets plus external resource list and limitations. |
| Component/template machine registries | PASS | 50 unique components and 19 unique templates; required schema fields present. |
| Compliance enforcement | PASS | Static checker, detailed text/JSON reports, unit tests, and a zero-failure demo exist. |
| Responsive runtime sample | PASS | Desktop page and nested 390×844 mobile viewport inspected in the in-app browser. |

## Practical “build a government home page” test

| Required decision | Can the deliverables answer it? | Where |
|---|---|---|
| Layout/container/grid | نعم | Master §§5–6; Quick Reference Layout |
| Header/navigation/breadcrumb | نعم | Master §§10–11, Component 38/46/47/49 |
| Hero/sections/cards/CTA | نعم | Home template and Component chooser |
| Colors/type/spacing | نعم | Master §5; Quick Design tokens |
| Footer/legal/contact | نعم, with entity-specific verification caveat | Master §§12, 21 |
| RTL/Arabic | نعم | Master §7; Quick RTL |
| Mobile/tablet/desktop | نعم | Master §17; Quick Responsive |
| Accessibility/keyboard/forms/states | نعم | Master §§8, 13–14 and checklists |
| Content | نعم at public-guideline level | Master §9; unresolved detailed language style noted |
| Exact React component props | **لا** | `⚠️ NEEDS VERIFICATION`; Storybook/API not public |

## Deliverable integrity

| File | Purpose | Status |
|---|---|---|
| `../UDS_FILES_USAGE_GUIDE_AR.md` | Arabic operational guide for using, validating, and maintaining the deliverables | Complete |
| `Saudi_Unified_Platform_Code_Master_Guide.md` | Full implementation knowledge base | Complete |
| `Saudi_Unified_Platform_Code_AI_Quick_Reference.md` | Context-efficient agent reference | Complete |
| `Saudi_Unified_Platform_Code_Rules.md` | 169 atomic traceable rules | Complete |
| `Saudi_Unified_Platform_Code_Coverage_Report.md` | Coverage evidence and limitations | Complete |
| `crawl_inventory.md` | Route/resource inventory | Complete |
| `uds-rules.json` | Machine-readable enriched rule registry | Complete |
| `uds-components.json` | Machine-readable 50-component registry | Complete |
| `uds-templates.json` | Machine-readable 19-template registry | Complete |
| `UDS_DEFINITION_OF_DONE.md` | Human and automated completion gate | Complete |
| `../AGENTS.md` | Mandatory repository AI workflow | Complete |
| `../tools/uds-compliance/` | Static checker, builders, tests, and usage guide | Complete |
| `../uds-validation-demo/` | Home-template implementation and persisted compliance reports | Complete |
| `official-resources/README.md` | Resource provenance and usage | Complete |

The complete route-by-route evidence remains in [`crawl_inventory.md`](./crawl_inventory.md); this report should be updated whenever the official site changes or exposes the missing external development resources.
