# Saudi Unified Platform Code — AI Quick Reference

> **Enforcement inputs:** [`uds-rules.json`](./uds-rules.json) (169 rules), [`uds-components.json`](./uds-components.json) (50 components), [`uds-templates.json`](./uds-templates.json) (19 templates), and [`UDS_DEFINITION_OF_DONE.md`](./UDS_DEFINITION_OF_DONE.md). Repository-level agent behavior is mandatory in [`../AGENTS.md`](../AGENTS.md).

> نسخة context مختصرة لوكيل برمجة. المصدر الأساسي: <https://design.dga.gov.sa/> · آخر تحقق: **2026-09-07** · النظام المعروض: **1.0**.
>
> تعامل مع `REQUIRED` كقيد تنفيذ. لا تخترع token أو component أو API. استخدم `⚠️ NEEDS VERIFICATION` للغموض و`INFERRED` للاستنتاج.

## Mandatory rules

1. `REQUIRED` الألوان الأساسية/الدلالية والخطوط والتخطيط والمسافات الرسمية.
2. `REQUIRED` Mobile-first وتجربة كاملة باللمس وviewport/navigation ملائمين.
3. `REQUIRED` واجهة عربية: `lang="ar" dir="rtl"` وترتيب DOM منطقي.
4. `REQUIRED` WCAG 2.1 AA: 4.5:1 للنص الصغير، 3:1 للنص ≥24px ولـUI/graphics.
5. `REQUIRED` لا تستخدم اللون وحده، وكل تفاعل keyboard مع focus ظاهر.
6. `REQUIRED` الهدف التفاعلي 44×44px على الأقل.
7. `REQUIRED` IBM Plex Sans Arabic للنص؛ الخط السعودي فقط لعناوين مناسبات وطنية/موسمية، لا للفقرات.
8. `RECOMMENDED` أعد استخدام component/icon/template الرسمي قبل تخصيص بديل.
9. `RECOMMENDED` العربية أولًا، محتوى واضح موجز، أخطاء قابلة للتصحيح، feedback فوري.

المصدر: [Assessment Criteria](https://design.dga.gov.sa/AssessmentCriteria)، [Foundations](https://design.dga.gov.sa/guidelines).

## Design tokens

### Core colors

| الدور | القيمة المحورية | السلم الكامل في الدليل الرئيسي |
|---|---|
| Primary SA Flag 600 | `#1b8354` | 25–950 |
| Secondary Gold 600 | `#dba102` | 25–950 |
| Tertiary Lavendar 500 | `#80519f` | 25–950 |
| Neutral 950 | `#0c111b` | 25–950 |
| Info Blue 600 | `#156fee` | 25–950 |
| Success Green 600 | `#069454` | 25–950 |
| Warning Yellow 600 | `#dc6803` | 25–950 |
| Error Red 600 | `#d92c20` | 25–950 |

لا تفترض أن الدرجة المحورية تصلح تلقائيًا لكل foreground/background؛ افحص contrast.

### Typography

`display`: 72/90, 60/72, 48/60, 36/44, 30/38, 24/32px.  
`text`: 20/30, 18/28, 16/24, 14/20, 12/18, 10/14px.  
Weights: Regular, Medium, Semibold, Bold. Font: IBM Plex Sans Arabic. Code: Roboto Mono.

### Spacing and geometry

- Semantic spacing px: `none 0`, `xxs 2`, `xs 4`, `sm 6`, `md 8`, `lg 12`, `xl 16`, `2xl 20`, `3xl 24`, `4xl 32`, `5xl 40`, `6xl 48`, `7xl 64`, `8xl 80`, `9xl 96`, `10xl 128`, `11xl 160`.
- Radius px: `0,2,4,6,8,10,12,16,20,24,9999`.
- Container: mobile padding 16px، desktop 32px، max 1280px، paragraph max 720px.
- Breakpoints: mobile 0–599؛ tablet 600–959؛ desktop 960–1279؛ XL 1280+.
- Grid: 12 columns desktop؛ 2–4 في الأضيق.

`⚠️ SOURCE CONFLICT`: جدول المصدر لا يطابق rem/px في width-xs وparagraph max؛ استخدم قيم px/CSS أعلاه وسجل التعارض.

## Layout

```text
Page
└─ Header / optional Second Nav
   └─ Main
      ├─ Breadcrumb (if hierarchical)
      ├─ Hero / Page heading
      ├─ Content sections (official grid + spacing)
      ├─ Primary task/CTA
      └─ Feedback / last-updated when template requires
   └─ Footer
```

- حاوية مرنة، reading order = visual order، whitespace وتجميع منطقي.
- لا قيم مسافات عشوائية. لا تتجاوز 1280px للحاوية؛ النص الطويل 720px.
- الجوال أولًا؛ stack headings/CTA عند الضيق؛ اختبر orientation وzoom.

## RTL and Arabic

- `html[lang="ar"][dir="rtl"]`; محاذاة/تدفق منطقيان.
- اعكس فقط الرموز الاتجاهية (سهم رجوع، previous/next، connectors)، لا الأيقونات غير الاتجاهية.
- لا تستخدم `row-reverse` لتصحيح واجهة مرتبة خطأ إذا خالف DOM/Tab.
- Breadcrumb mobile = رابط السابق + سهم؛ desktop full/abbreviated.
- Applied filter chips تعرض RTL وقابلة للحذف.
- الأرقام والتواريخ والهاتف والبريد والمحتوى المختلط: `⚠️ NEEDS VERIFICATION`؛ لا تدّع قاعدة رسمية غير منشورة.

## Accessibility

- semantic HTML before ARIA.
- Button للفعل، Link للانتقال.
- label ظاهر للحقول؛ `aria-describedby` للمساعدة/الخطأ؛ `aria-invalid="true"` للخطأ.
- Image meaningful alt؛ decorative `alt=""`; icon decorative `aria-hidden="true"`.
- dynamic noncritical: `role="status"` أو `aria-live="polite"`; critical immediate: `role="alert"`.
- modal: dialog + modal + accessible name + focus trap + restore focus.
- tabs: tablist/tab/tabpanel + arrows + selected/controls.
- progress: progressbar + min/max/now. Switch: switch + checked. Slider: slider + min/max/now.
- keyboard كامل، focus ظاهر، target ‏44×44، لا لون وحده، reduced motion.

## Component chooser

| الحاجة | استخدم | تجنب |
|---|---|---|
| فعل | Button | Link/div |
| انتقال | Link | Button |
| صفر/عدة خيارات | Checkbox | Radio |
| واحد من عدة | Radio | Checkboxes متنافية |
| on/off فوري | Switch | إعداد ينتظر submit |
| نص طويل | Textarea | Input |
| رقم مضبوط | Number input | Text input عام |
| قيمة/نطاق | Slider | بلا min/max/value |
| تاريخ | Datepicker | calendar بلا keyboard |
| ملف | File uploader | drag-only |
| 2–4 مشاهد | Content switcher | أكثر من 4 |
| أكثر من 4 مشاهد | Tabs | Content switcher |
| طي محتوى | Accordion | إخفاء معلومة حرجة |
| صفوف/أعمدة | Table | div-grid |
| KPI | Metric | رقم بلا label |
| علاقات بيانات | Charts | لون وحده |
| عملية غير محددة | Loading/Skeleton | شاشة فارغة |
| تقدم معروف | Progress bar | spinner |
| خطوات على mobile | Radial stepper | stepper أفقي مضغوط |
| رسالة inline/toast | Notification | Modal غير ضرورية |
| قرار معيق | Modal | focus غير مُدار |
| شرح قصير | Tooltip | معلومة أساسية tooltip-only |
| تضييق نتائج | Filtration + Tags | حالة غير معلنة |
| تسلسل صفحات | Pagination | current غير مميزة |

المكونات الرسمية الـ50 كاملة في [§13 من الدليل الرئيسي](./Saudi_Unified_Platform_Code_Master_Guide.md#13-components).

## Template selection

| page_type | القالب | التكوين |
|---|---|---|
| home | Home | Header, optional second nav, hero+CTA, services/features/news, feedback, footer |
| service | Service | Breadcrumb, summary, requirements/steps/content, CTA, feedback |
| form | Form | Intro, Steps desktop / Radial mobile, fields, validation, actions |
| search | Search | Search box, filters, tags, sort, results, pagination |
| faq | FAQs | Search, categories, accordion, optional pagination/rating |
| content | Content | Breadcrumb, TOC, headings, lists/media, feedback |
| help | Help | Search/cards/contact/feedback |
| about | About | Structure, strategy, policies, budget, procurement, partners, careers, news, contact |
| error_404 | Page Not Found | Clear message + recovery CTA |
| campaign | Hajj / Founding Day / National Day | Occasion-specific hero/assets/font + common shell |
| cookies | Cookie banner | Content/actions/error/preferences |
| chatbot | Chatbot | Welcome/features/conversation/accessibility/non-blocking position |
| dashboard | لا يوجد | `INFERRED`: Metric + Charts + Table + Filters |
| login/auth | لا يوجد | `⚠️ NEEDS VERIFICATION` |

FAQ rules: if >20 items, search and classification are preferred; on mobile show ≤5 categories otherwise dropdown; pagination allowed after 10. Two languages = direct switch; >2 = dropdown.

## Forms

1. Label + correct input type + help/constraint before action.
2. Group radio/checkbox with fieldset/legend.
3. Error inline, specific, linked, and not color-only.
4. Required/optional explicit; placeholder never replaces label.
5. Multi-step: numbered desktop، radial mobile، current `aria-current="step"`.
6. Preserve user input across validation; show loading then success/error.
7. Test Tab/Shift+Tab, Enter/Space, arrows/Esc where defined.

## Responsive rules

- Test exactly: 599, 600, 959, 960, 1279, 1280px plus representative widths.
- Mobile padding 16; desktop 32; max 1280.
- Breadcrumb collapses; nav becomes drawer/menu; forms use radial progress; long heading+CTA stack.
- Cards/images/forms/tables reflow or scroll accessibly; no clipping.
- Touch target 44×44 and controls remain reachable in portrait/landscape.

## Content rules

- Arabic-first, concise, direct, consistent government terminology.
- CTA states outcome; link states destination; error states correction.
- External/new-tab link warns user and uses `noopener noreferrer`.
- Heading hierarchy is semantic, not visual-only.
- Do not rely on icon/color alone.

## Implementation workflow

```text
1 Understand page + users + tasks + content.
2 Select official template or mark composition INFERRED.
3 Map every need to an official component.
4 Apply official typography, colors, spacing, grid.
5 Implement semantic HTML and RTL logical order.
6 Implement states + keyboard + ARIA relationships.
7 Implement responsive transformations.
8 Validate content and government/legal needs.
9 Test accessibility, mobile/tablet/desktop/XL.
10 Record evidence, conflicts, and unresolved verification.
```

ثم شغّل من جذر المستودع:

```bash
python3 tools/uds-compliance/uds_compliance.py <target>
```

أصلح كل `FAIL` وقيّم كل `WARNING`. لا تعتبر `MANUAL REVIEW` نجاحًا آليًا؛ أكمل الاختبارات البشرية المناسبة ثم استخدم صيغة تقرير الامتثال الإلزامية في `AGENTS.md`.

## Decision rules

```text
IF interface_language == ar THEN lang=ar AND dir=rtl.
IF official_component_exists THEN reuse it.
IF page_type matches official template THEN start from that template.
IF intent == navigate THEN Link ELSE IF intent == act THEN Button.
IF choices == one_of_many THEN Radio ELSE IF choices == zero_or_many THEN Checkbox.
IF binary_change_is_immediate THEN Switch.
IF related_views <= 4 THEN ContentSwitcher ELSE Tabs.
IF progress_is_known THEN ProgressBar ELSE Loading/Skeleton.
IF message_is_critical_and_immediate THEN alert ELSE status/polite.
IF official_REQUIRED conflicts with requested visual THEN enforce REQUIRED and report.
IF API/token/value is missing THEN do not invent; NEEDS VERIFICATION.
```

## Compliance checklist

- [ ] Official template selected / absence documented.
- [ ] Official components, icons, colors, typography, spacing, grid.
- [ ] `lang`, `dir`, DOM order, directional icons checked.
- [ ] Header/navigation/footer and page hierarchy correct.
- [ ] default/hover/pressed/focus/disabled/error/success/loading implemented as applicable.
- [ ] Keyboard, focus, names, labels, descriptions, live status tested.
- [ ] Contrast 4.5/3 and no color-only meaning.
- [ ] Touch target 44×44.
- [ ] Mobile/tablet/desktop/XL, zoom, orientation checked.
- [ ] Forms labels/required/help/error/success checked.
- [ ] Arabic copy/CTA/links/errors clear.
- [ ] Privacy/terms/contact/copyright/last-updated included where applicable.
- [ ] No invented tokens, classes, APIs, framework support, or rules.
- [ ] Every exception has level, source, and verification note.

## Known limitations

- Storybook وGitHub معروضان «قريبًا»؛ React package only: `platformscode-new-react@latest`.
- No published motion/z-index tokens or detailed APIs.
- Sitemap XML incomplete; live navigation inventory is authoritative for this snapshot.
- Source copy defects exist in Button/Card accessibility sections; do not propagate them.

للقيم الكاملة والمصادر والقوالب والمكونات: [`Saudi_Unified_Platform_Code_Master_Guide.md`](./Saudi_Unified_Platform_Code_Master_Guide.md). للقواعد الذرية: [`Saudi_Unified_Platform_Code_Rules.md`](./Saudi_Unified_Platform_Code_Rules.md). للحقائق المقروءة آليًا استخدم سجلات JSON الثلاثة، وللتنفيذ العملي راجع [`../tools/uds-compliance/README.md`](../tools/uds-compliance/README.md).
