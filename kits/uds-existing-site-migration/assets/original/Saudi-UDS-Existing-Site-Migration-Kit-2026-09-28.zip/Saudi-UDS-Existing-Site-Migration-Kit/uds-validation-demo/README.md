# UDS validation demo

عرض عربي مرجعي يختبر طبقة التحقق الخاصة بكود المنصات الموحد على قالب الصفحة الرئيسية.

## Implementation map

- **Template:** `UDS-TPL-HOME` — Home Page.
- **Official components represented:** Header, Main Navigation, Search, Buttons, Cards, Links, Radio, Metric, Feedback section, Last Updated, Footer.
- **Primary rule groups:** `UDS-MANDATORY-*`, `UDS-FOUND-*`, `UDS-LAYOUT-*`, `UDS-RTL-*`, `UDS-A11Y-*`, `UDS-CONTENT-*`, `UDS-NAV-*`, `UDS-HEADER-*`, `UDS-FOOTER-*`, `UDS-RESP-*`, and the selected component/template rules.
- **Checker annotations:** `data-uds-component` and `data-uds-template` are repository-level `INFERRED` hooks for static verification. They are not claimed as official public component APIs.

## Automated result

Run:

```bash
python3 tools/uds-compliance/uds_compliance.py uds-validation-demo \
  --json-out uds-validation-demo/compliance-report.json \
  --text-out uds-validation-demo/compliance-report.txt
```

Expected audited result: 25 `PASS`, 0 `FAIL`, 0 `WARNING`, and 144 `MANUAL REVIEW`. Manual-review entries mean the rule cannot be fully proved by a static scanner; they are not failures.

## Runtime and visual evidence

- Desktop: verified in the in-app browser; RTL layout, landmarks, heading order, labels, footer, and visual hierarchy render correctly.
- Interaction: search input accepts Arabic text; the feedback radio group changes checked state and exposes that state in the accessibility tree.
- Mobile: [`responsive-preview.html`](./responsive-preview.html) embeds the same page at 390×844, causing the page's mobile media queries to run in a genuine narrow viewport.
- Responsive rules: mobile-first layout plus the published 600px, 960px, and 1280px breakpoints are implemented in `styles.css`.
- Contrast spot checks: white/`#1b8354` = 4.75:1; white/`#14573a` = 8.56:1; `#111927`/`#f7fdf9` = 17.09:1; `#384250`/white = 10.18:1.

Keyboard-only, screen-reader software, 200%/400% zoom, orientation, and assistive-technology interoperability remain explicit human acceptance checks under [`UDS_DEFINITION_OF_DONE.md`](../.design-system/UDS_DEFINITION_OF_DONE.md).
