#!/usr/bin/env python3
"""Build the audited Markdown rule catalog and machine-readable JSON registry."""

from __future__ import annotations

import json
import re
from collections import OrderedDict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DS = ROOT / ".design-system"
RULES_MD = DS / "Saudi_Unified_Platform_Code_Rules.md"
INVENTORY_MD = DS / "crawl_inventory.md"
RULES_JSON = DS / "uds-rules.json"
VERIFIED_ON = "2026-09-07"

RULE_ROW = re.compile(
    r"^\|\s*(UDS-[A-Z0-9-]+)\s*\|\s*([^|]+?)\s*\|\s*"
    r"(REQUIRED|RECOMMENDED|OPTIONAL|INFERRED)\s*\|\s*(.*?)\s*\|\s*"
    r"<([^>]+)>\s*\|(?:.*\|)?$"
)
INVENTORY_ROW = re.compile(
    r"^\|\s*\d+\s*\|\s*(https://design\.dga\.gov\.sa/[^ ]*)\s*\|\s*([^|]+?)\s*\|"
)

AUTOMATED_IDS = {
    "UDS-TYPO-001",
    "UDS-LAYOUT-013",
    "UDS-RTL-001",
    "UDS-A11Y-005",
    "UDS-A11Y-007",
    "UDS-A11Y-008",
    "UDS-A11Y-009",
    "UDS-A11Y-010",
    "UDS-A11Y-014",
    "UDS-A11Y-016",
    "UDS-A11Y-017",
    "UDS-A11Y-018",
    "UDS-A11Y-019",
    "UDS-A11Y-020",
    "UDS-COMP-BUTTON-001",
    "UDS-COMP-LINK-002",
    "UDS-COMP-LIST-001",
    "UDS-COMP-TABLE-001",
    "UDS-COMP-STEPS-001",
    "UDS-COMP-BREADCRUMB-001",
    "UDS-COMP-PAGINATION-001",
    "UDS-COMP-SEARCH-001",
    "UDS-COMP-TOC-001",
    "UDS-COMP-FOOTER-001",
    "UDS-CONTENT-004",
}

SEMI_AUTOMATED_PREFIXES = (
    "UDS-COLOR-",
    "UDS-TYPO-",
    "UDS-LAYOUT-",
    "UDS-ELEV-",
    "UDS-RTL-",
    "UDS-A11Y-",
    "UDS-COMP-",
    "UDS-FORM-",
    "UDS-QUALITY-",
)


def source_titles() -> dict[str, str]:
    titles: dict[str, str] = {}
    for line in INVENTORY_MD.read_text(encoding="utf-8").splitlines():
        match = INVENTORY_ROW.match(line)
        if match:
            titles[match.group(1)] = match.group(2).strip()
    return titles


def page_title(url: str, titles: dict[str, str]) -> str:
    if url in titles:
        return titles[url]
    known = {
        "https://design.dga.gov.sa/": "نظام التصميم الموحد للمملكة العربية السعودية",
        "https://design.dga.gov.sa/guidelines": "الإرشادات",
    }
    return known.get(url, "NOT PUBLISHED BY OFFICIAL SOURCE")


def testability(rule_id: str) -> str:
    if rule_id in AUTOMATED_IDS:
        return "AUTOMATED"
    if rule_id.startswith(SEMI_AUTOMATED_PREFIXES):
        return "SEMI_AUTOMATED"
    return "MANUAL"


def implementation_notes(rule_id: str, category: str, level: str) -> str:
    if rule_id in AUTOMATED_IDS:
        return (
            "نفّذها في البنية الدلالية/السمات، ثم شغّل tools/uds-compliance؛ "
            "الفحص الساكن يثبت وجود النمط ولا يغني عن اختبار السلوك عند التشغيل."
        )
    if rule_id.startswith("UDS-COLOR-"):
        return "استهلك القيمة عبر طبقة tokens الرسمية، ثم تحقق من الألوان المحسوبة والتباين في السياق الفعلي."
    if rule_id.startswith("UDS-TYPO-"):
        return "اربط النمط بـtypography token المنشور، ثم راجع الحجم والوزن وارتفاع السطر بصريًا وعلى الشاشات الصغيرة."
    if rule_id.startswith(("UDS-LAYOUT-", "UDS-ELEV-")):
        return "استخدم token/breakpoint المنشور؛ راجع القيمة في CSS ثم اختبر إعادة التدفق بصريًا في النطاقات الأربعة."
    if rule_id.startswith("UDS-RTL-"):
        return "اختبر DOM وترتيب Tab والرموز الاتجاهية والمحتوى المختلط في واجهة عربية فعلية، لا بعكس CSS بصري فقط."
    if rule_id.startswith("UDS-A11Y-"):
        return "نفّذ الدلالة والعلاقة المطلوبة، ثم اجمع فحصًا آليًا مع لوحة المفاتيح وقارئ الشاشة والمراجعة البصرية."
    if rule_id.startswith("UDS-COMP-"):
        return "استخدم المكون الرسمي وحالاته؛ افحص الـmarkup آليًا ثم تحقق يدويًا من اختيار المكون والسلوك المتجاوب."
    if rule_id.startswith("UDS-FORM-"):
        return "اختبر المسار الناجح والخطأ ولوحة المفاتيح والجوال، وتأكد من بقاء الرسالة مرتبطة بالحقل."
    if rule_id.startswith("UDS-TEMPLATE-"):
        return "طبّقها فقط عند اختيار القالب المذكور، ووثق الأقسام المحذوفة أو المضافة وسببها."
    if rule_id.startswith("UDS-DEV-"):
        return "تحقق من المصدر والإصدار قبل التثبيت أو الترحيل، ولا تستنتج API من حزمة البناء المصغرة."
    if rule_id.startswith(("UDS-CONTENT-", "UDS-PLATFORM-")):
        return "تحتاج مراجعة بشرية للسياق والوضوح واحتياجات الجهة، مع إبقاء رابط المصدر في قرار."
    note = "راجع التطبيق مقابل المصدر الرسمي وسجل الدليل أو الاستثناء في تقرير الامتثال."
    if level == "INFERRED":
        note += " هذه قاعدة تشغيلية مستنتجة وليست متطلبًا رسميًا مستقلًا."
    return note


def parse_rules() -> tuple[list[dict], OrderedDict[str, list[dict]], list[str]]:
    titles = source_titles()
    rules: list[dict] = []
    sections: OrderedDict[str, list[dict]] = OrderedDict()
    current_section = "Ungrouped"
    for line in RULES_MD.read_text(encoding="utf-8").splitlines():
        if line.startswith("## "):
            current_section = line[3:].strip()
            if current_section.startswith("Known source"):
                break
            sections.setdefault(current_section, [])
            continue
        match = RULE_ROW.match(line)
        if not match:
            continue
        rule_id, category, level, rule, source_url = match.groups()
        item = {
            "id": rule_id,
            "category": category.strip(),
            "level": level,
            "rule": rule.strip(),
            "source_url": source_url,
            "source_page_title": page_title(source_url, titles),
            "verification_date": VERIFIED_ON,
            "implementation_notes": implementation_notes(
                rule_id, category.strip(), level
            ),
            "testability": testability(rule_id),
        }
        rules.append(item)
        sections.setdefault(current_section, []).append(item)
    if len({item["id"] for item in rules}) != len(rules):
        raise SystemExit("Duplicate rule IDs found")
    if any(r["source_page_title"] == "NOT PUBLISHED BY OFFICIAL SOURCE" for r in rules):
        missing = [
            r["source_url"]
            for r in rules
            if r["source_page_title"] == "NOT PUBLISHED BY OFFICIAL SOURCE"
        ]
        raise SystemExit(f"Missing source titles: {sorted(set(missing))}")
    return rules, sections, []


def write_json(rules: list[dict]) -> None:
    payload = {
        "schema_version": "1.0.0",
        "system": "Saudi Unified Platform Code",
        "official_site": "https://design.dga.gov.sa/",
        "verification_date": VERIFIED_ON,
        "rule_count": len(rules),
        "levels": ["REQUIRED", "RECOMMENDED", "OPTIONAL", "INFERRED"],
        "testability_values": ["AUTOMATED", "SEMI_AUTOMATED", "MANUAL"],
        "rules": rules,
    }
    RULES_JSON.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def escape_cell(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", " ")


def write_markdown(sections: OrderedDict[str, list[dict]], rules: list[dict]) -> None:
    out = [
        "# Saudi Unified Platform Code — Audited Traceable Rules",
        "",
        "> Canonical human-readable projection of `uds-rules.json`.",
        ">",
        f"> **Rule count:** {len(rules)} · **Verification date:** {VERIFIED_ON}",
        ">",
        "> `INFERRED` is an implementation inference, not an official standalone requirement. Testability is `AUTOMATED`, `SEMI_AUTOMATED`, or `MANUAL`.",
        "",
    ]
    header = (
        "| Rule ID | Category | Requirement Level | Rule | Source URL | "
        "Source Page Title | Verification Date | Implementation Notes | Testability |"
    )
    separator = "|---|---|---|---|---|---|---|---|---|"
    for section, items in sections.items():
        if not items:
            continue
        out.extend([f"## {section}", "", header, separator])
        for item in items:
            cells = [
                item["id"],
                item["category"],
                item["level"],
                item["rule"],
                f'<{item["source_url"]}>',
                item["source_page_title"],
                item["verification_date"],
                item["implementation_notes"],
                item["testability"],
            ]
            out.append("| " + " | ".join(escape_cell(c) for c in cells) + " |")
        out.append("")
    out.extend(
        [
            "## Duplicate and conflict audit",
            "",
            "- Exact duplicate IDs: **0**.",
            "- Exact duplicate rule texts: **0**.",
            "- Semantic overlaps retained only where a global requirement and a component-specific enforcement rule have different scopes.",
            "- `SOURCE-CONFLICT-001`: `sitemap.xml` contains 78 URLs while live navigation exposes 96.",
            "- `SOURCE-CONFLICT-002`: `robots.txt` points at `https://yourdomain.com/sitemap.xml`.",
            "- `SOURCE-CONFLICT-003`: `critical.css`, `non-critical.js`, and `sitemap_index.xml` return the HTML app shell.",
            "- `SOURCE-CONFLICT-004`: the layout table publishes non-equivalent rem/px pairs for `width-xs` and `paragraph-max-width`.",
            "- `SOURCE-CONFLICT-005`: Card accessibility copy refers to Accordion; Button copy contains Notification live-region guidance. Neither defect is enforced.",
            "",
            "The JSON file is the machine-readable authority; this Markdown file exists for review and traceability.",
        ]
    )
    RULES_MD.write_text("\n".join(out) + "\n", encoding="utf-8")


def main() -> None:
    rules, sections, _ = parse_rules()
    normalized = [re.sub(r"\W+", " ", r["rule"].lower()).strip() for r in rules]
    if len(set(normalized)) != len(normalized):
        raise SystemExit("Exact normalized duplicate rule texts found")
    write_json(rules)
    write_markdown(sections, rules)
    counts = {name: sum(r["testability"] == name for r in rules) for name in (
        "AUTOMATED", "SEMI_AUTOMATED", "MANUAL"
    )}
    print(json.dumps({"rules": len(rules), "testability": counts}, ensure_ascii=False))


if __name__ == "__main__":
    main()
