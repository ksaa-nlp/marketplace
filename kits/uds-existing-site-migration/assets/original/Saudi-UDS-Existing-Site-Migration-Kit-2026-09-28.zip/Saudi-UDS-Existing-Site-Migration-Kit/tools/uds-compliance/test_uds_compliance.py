#!/usr/bin/env python3

from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SPEC = importlib.util.spec_from_file_location("uds_compliance", HERE / "uds_compliance.py")
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


GOOD_HTML = """<!doctype html>
<html lang="ar" dir="rtl" data-uds-template="home">
<head><meta name="viewport" content="width=device-width, initial-scale=1"><title>اختبار</title></head>
<body>
<a href="#main-content">تجاوز إلى المحتوى</a>
<header><nav aria-label="الرئيسية"><a href="/">الرئيسية</a></nav></header>
<main id="main-content"><h1>عنوان عربي واضح</h1>
<form role="search" data-uds-component="search-box"><label for="q">البحث في المحتوى</label><input id="q" type="search"></form>
<img src="x.svg" alt="وصف الصورة">
<button type="button" aria-label="إغلاق"><svg aria-hidden="true"></svg></button>
<table><thead><tr><th scope="col">الخدمة</th></tr></thead><tbody><tr><td>مثال</td></tr></tbody></table>
</main><footer><a href="/privacy">الخصوصية</a></footer>
</body></html>"""

BAD_HTML = """<!doctype html><html><head><title>سيئ</title></head><body>
<h1>عنوان عربي طويل للتحقق من أن الصفحة عربية وتحتاج اتجاهًا ولغة صحيحة</h1>
<img src="x.png"><input id="name"><div onclick="go()">تابع</div>
<a target="_blank">رابط</a><button><svg></svg></button>
</body></html>"""


class ComplianceCheckerTests(unittest.TestCase):
    def run_fixture(self, html: str):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "index.html"
            path.write_text(html, encoding="utf-8")
            checker = MODULE.Checker(path, ROOT / ".design-system" / "uds-rules.json")
            return checker.run()

    def test_good_semantic_fixture_has_no_failures(self):
        report = self.run_fixture(GOOD_HTML)
        self.assertEqual(report["summary"]["FAIL"], 0)

    def test_bad_fixture_reports_core_failures(self):
        report = self.run_fixture(BAD_HTML)
        failed = {item["rule_id"] for item in report["findings"] if item["severity"] == "FAIL"}
        self.assertTrue({"UDS-RTL-001", "UDS-A11Y-007", "UDS-A11Y-008", "UDS-COMP-BUTTON-001"}.issubset(failed))

    def test_registry_counts_and_traceability(self):
        payload = json.loads((ROOT / ".design-system" / "uds-rules.json").read_text(encoding="utf-8"))
        self.assertEqual(payload["rule_count"], 169)
        self.assertEqual(len({item["id"] for item in payload["rules"]}), 169)
        required = {"id", "category", "level", "rule", "source_url", "source_page_title", "verification_date", "implementation_notes", "testability"}
        self.assertTrue(all(required.issubset(item) for item in payload["rules"]))

    def test_component_registry_schema_and_rule_references(self):
        rules = json.loads((ROOT / ".design-system" / "uds-rules.json").read_text(encoding="utf-8"))
        payload = json.loads((ROOT / ".design-system" / "uds-components.json").read_text(encoding="utf-8"))
        valid_rule_ids = {item["id"] for item in rules["rules"]}
        required = {
            "component", "name", "official", "group", "purpose", "usage",
            "when_to_use", "when_not_to_use", "anatomy", "variants", "sizes",
            "states", "hover", "focus", "active", "disabled", "error",
            "success", "loading", "rtl", "responsive", "accessibility",
            "keyboard", "aria", "content", "design_tokens", "do", "dont",
            "code_example", "rules", "source", "source_page_title",
            "verification_date",
        }
        self.assertEqual(payload["not_published_marker"], "NOT PUBLISHED BY OFFICIAL SOURCE")
        self.assertEqual(payload["component_count"], 50)
        self.assertEqual(len(payload["components"]), 50)
        self.assertEqual(len({item["component"] for item in payload["components"]}), 50)
        self.assertTrue(all(required.issubset(item) for item in payload["components"]))
        self.assertTrue(all(set(item["rules"]).issubset(valid_rule_ids) for item in payload["components"]))

    def test_template_registry_schema_and_rule_references(self):
        rules = json.loads((ROOT / ".design-system" / "uds-rules.json").read_text(encoding="utf-8"))
        payload = json.loads((ROOT / ".design-system" / "uds-templates.json").read_text(encoding="utf-8"))
        valid_rule_ids = {item["id"] for item in rules["rules"]}
        required = {
            "template_id", "template", "official", "use_case",
            "documented_sections", "required_sections", "optional_sections",
            "component_hierarchy", "required_components", "optional_components",
            "layout", "header_type", "navigation", "hero", "main_content", "cta",
            "footer", "responsive_rules", "rtl", "accessibility", "content_rules",
            "rules", "sources", "source_page_title", "verification_date",
        }
        self.assertEqual(payload["not_published_marker"], "NOT PUBLISHED BY OFFICIAL SOURCE")
        self.assertEqual(payload["template_count"], 19)
        self.assertEqual(len(payload["templates"]), 19)
        self.assertEqual(len({item["template_id"] for item in payload["templates"]}), 19)
        self.assertTrue(all(required.issubset(item) for item in payload["templates"]))
        self.assertTrue(all(set(item["rules"]).issubset(valid_rule_ids) for item in payload["templates"]))


if __name__ == "__main__":
    unittest.main()
