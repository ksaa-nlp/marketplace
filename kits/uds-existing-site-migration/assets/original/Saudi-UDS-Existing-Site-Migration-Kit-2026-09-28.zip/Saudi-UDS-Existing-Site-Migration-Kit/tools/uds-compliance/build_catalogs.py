#!/usr/bin/env python3
"""Build strict component and template registries from audited public guidance."""

from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DS = ROOT / ".design-system"
NP = "NOT PUBLISHED BY OFFICIAL SOURCE"
VERIFIED = "2026-09-07"
BASE = "https://design.dga.gov.sa/guidelines/components/"
TBASE = "https://design.dga.gov.sa/guidelines/templates/"


def component(
    slug,
    name,
    group,
    path,
    purpose,
    usage,
    anatomy,
    variants=NP,
    sizes=NP,
    states=NP,
    accessibility=NP,
    keyboard=NP,
    aria=NP,
    rtl=NP,
    responsive=NP,
    content=NP,
    do=NP,
    dont=NP,
    rules=None,
):
    states_list = states if isinstance(states, list) else []

    def state(name):
        aliases = {"active": {"active", "pressed", "selected"}}
        candidates = aliases.get(name, {name})
        return name.upper() if any(candidate in states_list for candidate in candidates) else NP

    return {
        "component": slug,
        "name": name,
        "official": True,
        "group": group,
        "purpose": purpose,
        "usage": usage,
        "when_to_use": usage,
        "when_not_to_use": dont,
        "anatomy": anatomy,
        "variants": variants,
        "sizes": sizes,
        "states": states,
        "hover": state("hover"),
        "focus": state("focus"),
        "active": state("active"),
        "disabled": state("disabled"),
        "error": state("error"),
        "success": state("success"),
        "loading": state("loading"),
        "rtl": rtl,
        "responsive": responsive,
        "accessibility": accessibility,
        "keyboard": keyboard,
        "aria": aria,
        "content": content,
        "design_tokens": NP,
        "do": do,
        "dont": dont,
        "code_example": NP,
        "rules": rules or [],
        "source": BASE + path,
        "source_page_title": name,
        "verification_date": VERIFIED,
    }


COMPONENTS = [
    component("button", "الأزرار", "actions", "actions/buttons", "تنفيذ فعل واضح داخل الواجهة.", "استخدمه للإجراء؛ مستويات التأكيد high/medium/low، وأنواع قياسي وتحذيري وقائمة وأيقوني وإغلاق.", ["container", "label", "leading icon", "trailing icon"], ["standard", "destructive", "menu", "icon", "close"], states=["default", "hover", "pressed", "selected", "focus", "disabled"], accessibility="عنصر button دلالي، تباين 4.5:1، هدف 44×44، واسم وصول للأيقوني.", keyboard=["Tab", "Enter", "Space"], aria=["aria-label for icon-only"], content="تسمية تصف نتيجة الفعل.", dont="لا تستخدمه للتنقل ولا تنشئ عدة إجراءات high متنافسة.", rules=["UDS-COMP-BUTTON-001", "UDS-COMP-BUTTON-002", "UDS-COMP-BUTTON-003"]),
    component("floating-button", "الزر العائم", "actions", "actions/floating-Button", "إبراز إجراء دائري عالي الأولوية.", "للإجراء العائم المتكرر عندما لا يحجب المحتوى.", ["container", "icon", "optional label"], states=["default", "hover", "pressed", "focus", "disabled"], accessibility="اسم وصول وصفي وهدف تفاعلي كبير.", keyboard=["Tab", "Enter", "Space"], aria=["aria-label"], responsive="يجب ألا يحجب المحتوى في المساحات الضيقة."),
    component("dropdown", "القائمة المنسدلة", "actions", "actions/dropdown", "اختيار خيار من قائمة مؤقتة.", "عندما تحتاج قائمة خيارات قابلة للفتح والطي.", ["label", "trigger", "list", "options"], ["outlined", "filled light", "filled dark"], states=["default", "hover", "focus", "selected", "disabled", "error"], accessibility="عرّف المشغل والقائمة والخيارات والحالة المختارة.", keyboard=["Tab", "Arrow keys", "Enter", "Space", "Escape"], aria=["aria-haspopup=listbox", "aria-expanded", "role=listbox", "role=option", "aria-selected"], rules=[]),
    component("link", "الرابط", "actions", "actions/link", "الانتقال إلى صفحة أو موضع أو مورد.", "استخدم a مع href عندما تكون النتيجة انتقالًا.", ["text", "optional icon"], states=["default", "hover", "pressed", "focus", "visited", "disabled"], accessibility="نص وصفي، underline افتراضي، تباين 4.5:1، وتحذير فتح نافذة جديدة.", keyboard=["Tab", "Enter"], aria=NP, rtl="اعكس الأيقونة فقط إذا حملت معنى اتجاهيًا.", content="النص يصف الوجهة.", dont="لا تستخدمه لفعل محلي.", rules=["UDS-COMP-LINK-001", "UDS-COMP-LINK-002"]),
    component("chip", "العلامات التفاعلية", "actions", "actions/chip", "تصنيف أو اختيار أو مرشح أو إجراء صغير.", "لعنصر موجز قابل للاختيار أو الإزالة.", ["container", "text", "leading icon", "trailing icon"], states=["default", "hover", "pressed", "selected", "focus", "disabled"], accessibility="عامل القابل للإزالة كزر باسم وصول واضح.", keyboard=["Tab", "Enter", "Space"], aria=["aria-label for removal"], rtl="رتب النص وأيقونة الإزالة وفق RTL.", responsive="تلتف مجموعة الشرائح دون قص.", dont="لا تستخدم نصًا طويلًا أو عددًا يسبب ضوضاء.", rules=["UDS-COMP-CHIP-001"]),

    component("accordion", "أكورديون", "content-display", "content-display/accordion", "كشف وطي أقسام محتوى.", "لأقسام مرتبطة لا يلزم عرضها كلها في وقت واحد.", ["header trigger", "title", "expand icon", "panel"], states=["collapsed", "expanded", "hover", "focus", "disabled"], accessibility="زر رأس يعلن حالة التوسع ويرتبط باللوحة.", keyboard=["Tab", "Enter", "Space"], aria=["aria-expanded", "aria-controls"], rules=["UDS-COMP-ACCORDION-001"]),
    component("card", "البطاقة", "content-display", "content-display/card", "تجميع محتوى أو إجراء مترابط.", "لعرض صورة/عنوان/وصف/وسوم/تقييم/إجراءات كوحدة.", ["container", "image", "featured icon", "title", "description", "avatar", "tags", "rating", "actions"], states=NP, accessibility="فقرة الوصول الرسمية متعارضة ومنسوخة من Accordion؛ استخدم دلالة الروابط/الأزرار العامة.", keyboard=NP, aria=NP, responsive="تُرص عناصر البطاقة عند ضيق العرض وفق القوالب.", content="البطاقة القابلة للفعل لها CTA واضح؛ بطاقة العرض قد لا تحتاجه.", dont="لا تجعل div كاملًا قابلًا للنقر بلا دلالة.", rules=["UDS-COMP-CARD-001"]),
    component("carousel", "عنصر التمرير", "content-display", "content-display/carousel", "عرض سلسلة عناصر داخل مساحة واحدة.", "لعناصر متتابعة مع أزرار ونقاط موضع.", ["viewport", "items", "previous", "next", "dots", "current item"], ["manual", "automatic"], states=["default", "focus", "selected"], accessibility="سمّ التحكمات وأعلن تغير الشريحة ولا تفقد التركيز.", keyboard=["Tab", "Arrow keys"], aria=["role=listbox", "role=option", "aria-roledescription", "aria-live for automatic changes"], rtl="اعكس السابق/التالي وفق الاتجاه.", dont="لا تستخدم تشغيلًا تلقائيًا بلا تحكم أو لإخفاء محتوى أساسي.", rules=["UDS-COMP-CAROUSEL-001"]),
    component("list", "قائمة التعداد", "content-display", "content-display/list", "عرض عناصر مرتبة أو غير مرتبة.", "استخدم ol للتسلسل وul للتجميع.", ["list container", "list item", "marker", "content"], ["ordered", "unordered"], states=NP, accessibility="استخدم ol/ul/li الدلالية.", keyboard=["Tab for interactive descendants"], aria=["aria-current=page when used in navigation"], rtl="تظهر العلامات والمحاذاة في الطرف المنطقي.", rules=["UDS-COMP-LIST-001"]),
    component("code-snippet", "مستعرض الكود", "content-display", "content-display/code-snippet", "عرض شفرة قابلة للقراءة والنسخ.", "لعرض مقتطفات مع لغة ونسخ وأرقام أسطر/توسيع عند الحاجة.", ["code area", "language tabs", "copy", "line numbers", "show more"], states=["default", "focus", "success", "error"], accessibility="حافظ على التنسيق وأعلن نجاح النسخ وأخف أرقام الأسطر الزخرفية.", keyboard=["Tab", "Enter", "Space"], aria=["aria-live=polite for copy status", "aria-hidden for decorative line numbers"], rtl="اعرض الشفرة LTR داخل سياق RTL.", rules=["UDS-COMP-CODE-001"]),
    component("quote", "الاقتباس", "content-display", "content-display/quote", "عرض اقتباس منسوب.", "لنص مقتبس مع اسم/صفة/صورة المؤلف عند توفرها.", ["quote title", "text", "author name", "author title", "image", "quote marks"], states=NP, accessibility="استخدم blockquote وأخف علامات الاقتباس الزخرفية.", aria=["aria-hidden for decorative marks"], rtl="استخدم dir=rtl للاقتباس العربي.", dont="لا تستخدمه كنمط زخرفي لنص غير مقتبس.", rules=["UDS-COMP-QUOTE-001"]),
    component("divider", "الخط الفاصل", "content-display", "content-display/divider", "فصل بصري أو بنيوي.", "عندما يزيد وضوح مجموعات المحتوى.", ["line or spacing boundary"], states=NP, accessibility="role=separator للبنيوي وإخفاء الزخرفي.", aria=["role=separator or aria-hidden"], responsive="يمكن حذفه عند الضيق إذا بقيت البنية واضحة.", dont="لا تفرط في استخدامه ولا تستبدل hierarchy والمسافات به.", rules=["UDS-COMP-DIVIDER-001"]),
    component("digital-stamp", "الختم الرقمي", "content-display", "content-display/digital-stamp", "إظهار أصالة وثقة منصة رسمية.", "لنطاق مؤهل يستخدم HTTPS ومستوفٍ شروط التسجيل/الترخيص.", ["status", "domain/details", "icons", "verification link"], states=["verified"], accessibility="حالة معلنة وأسماء للأيقونات ذات المعنى ورابط لوحة مفاتيح.", keyboard=["Tab", "Enter"], aria=["role=status", "aria-label", "aria-hidden for decorative icons"], dont="لا تعرضه ادعاءً بلا استيفاء الشروط.", rules=["UDS-COMP-STAMP-001", "UDS-PLATFORM-007"]),

    component("avatar", "الصورة الرمزية", "data-display", "data-display/avatar", "تمثيل شخص أو كيان بصريًا.", "للصورة أو الأحرف الأولى أو الأيقونة.", ["image or initials/icon", "container"], ["circle", "rectangle"], [24, 32, 40, 48, 64, 80, 120], accessibility="alt للاسم/الغرض، أو alt فارغ للزخرفي.", aria=NP, rules=["UDS-COMP-AVATAR-001"]),
    component("metric", "بطاقة المؤشرات", "data-display", "data-display/metric", "عرض قيمة مؤشر وسياقها واتجاهها.", "لـKPI مع label وقيمة وtrend/chart/action اختياري.", ["label", "value", "trend", "chart", "settings", "CTA"], states=["default", "loading", "error"], accessibility="أعلن التغير المهم بلطف وسمّ الإجراءات والأيقونات.", keyboard=["Tab", "Enter", "Space"], aria=["aria-live=polite", "aria-label"], content="القيمة تحتاج label وسياق/وحدة مناسبة.", rules=["UDS-COMP-METRIC-001"]),
    component("table", "الجدول", "data-display", "data-display/table", "عرض بيانات صفوف وأعمدة للمقارنة.", "للبيانات الجدولية ذات رؤوس واضحة.", ["table", "caption", "column headers", "row headers", "body", "cells", "optional selection/actions"], states=["default", "hover", "focus", "selected", "loading", "error"], accessibility="HTML table مع th/scope؛ ARIA فقط عند عدم كفاية الدلالة الأصلية.", keyboard=["Tab for interactive cells"], aria=NP, rtl="محاذاة وترتيب الأعمدة وفق RTL.", responsive="overflow متاح دون قص؛ نمط التحويل إلى بطاقات غير منشور.", dont="لا تستخدم جدولًا لتخطيط الصفحة.", rules=["UDS-COMP-TABLE-001"]),
    component("content-switcher", "مُبدّل المحتوى", "data-display", "data-display/content-switcher", "التبديل بين مشاهد مرتبطة.", "لخيارين إلى أربعة؛ استخدم Tabs لأكثر من أربعة.", ["option list", "selected indicator", "panels"], states=["default", "hover", "focus", "selected", "disabled"], accessibility="استخدم tab semantics وعلاقات اللوحات.", keyboard=["Tab", "Arrow keys"], aria=["role=tablist", "role=tab", "role=tabpanel", "aria-selected", "aria-controls"], rtl="اتجاه المجموعة والأسهم وفق RTL.", rules=["UDS-COMP-SWITCHER-001"]),
    component("charts", "الرسوم البيانية", "data-display", "data-display/charts", "تصوير علاقات واتجاهات البيانات.", "للـpie/line/bar عندما يكون الرسم أوضح من النص وحده.", ["title", "axes", "labels", "plot", "legend", "data points"], ["pie", "line", "bar"], states=["default", "hover", "focus", "selected", "loading", "error"], accessibility="ملخص نصي وعناوين؛ لا لون وحده؛ نقاط تفاعلية بلوحة المفاتيح.", keyboard=["Tab", "Arrow keys for interactive points"], aria=["role=img for static chart", "aria-label or labelledby"], responsive="يعيد الرسم التدفق على المقاسات المختلفة.", dont="لا تستخدم الرسم حين تكون قيمة/قائمة أبسط.", rules=["UDS-COMP-CHART-001", "UDS-A11Y-022"]),
    component("structured-list", "القائمة المنظَّمة", "data-display", "data-display/structured-list", "عرض بيانات منظمة أخف من جدول معقد.", "لصفوف/أعمدة وفواصل واختيار صف اختياري.", ["header", "rows", "cells", "optional checkbox", "dividers", "container"], states=["default", "focus", "selected"], accessibility="استخدم list/listitem أو table roles بحسب البنية الفعلية.", keyboard=["Tab", "Space for row selection"], aria=["role=list/listitem or table/row/columnheader/rowheader"], rtl="اتجاه الأعمدة والمحاذاة RTL."),

    component("notification", "الإشعارات", "feedback", "feedback/notification", "إبلاغ المستخدم بحالة أو نتيجة.", "inline أو toast؛ معلومات/نجاح/تحذير/خطأ/محايد؛ قابل للإجراء عند الحاجة.", ["icon", "title", "message", "action", "dismiss"], ["inline", "toast", "actionable", "with background", "without background"], states=["info", "success", "warning", "error", "neutral"], accessibility="alert للحرج الفوري وstatus/polite لغير الحرج؛ وقت قراءة كافٍ.", keyboard=["Tab", "Enter", "Space"], aria=["role=alert", "role=status", "aria-live=polite"], rules=["UDS-COMP-NOTIFICATION-001", "UDS-A11Y-011", "UDS-A11Y-012"]),
    component("modal", "النوافذ المنبثقة", "feedback", "feedback/modal", "قرار أو مهمة مركزة تحجب الخلفية.", "عندما يلزم إيقاف السياق حتى قرار/إجراء.", ["overlay", "dialog", "title", "description", "content", "actions", "close"], states=["closed", "open", "loading", "error"], accessibility="اسم حوار، focus trap، إخفاء الخلفية، وإعادة التركيز.", keyboard=["Tab", "Shift+Tab", "Escape"], aria=["role=dialog", "aria-modal=true", "aria-labelledby"], responsive="داخل viewport وقابل للتمرير في الجوال.", dont="لا تستخدمه لمعلومة غير معيقة يمكن عرضها inline.", rules=["UDS-A11Y-014", "UDS-A11Y-015"]),
    component("tooltip", "التلميح", "feedback", "feedback/tooltip", "شرح موجز لمشغّل.", "لمساعدة قصيرة تظهر hover وfocus.", ["trigger", "bubble", "arrow"], ["top", "bottom", "left", "right", "light", "dark"], states=["hidden", "hover", "focus"], accessibility="يظهر على focus ويختفي blur/Escape ولا ينقل التركيز إن لم يكن تفاعليًا.", keyboard=["Tab", "Escape"], aria=["role=tooltip", "aria-describedby"], responsive="ابقه داخل viewport.", dont="لا تجعل معلومة أساسية متاحة في tooltip فقط.", rules=["UDS-COMP-TOOLTIP-001"]),
    component("rating", "التقييم", "feedback", "feedback/rating", "اختيار أو عرض درجة نجوم.", "لجمع تقييم رقمي أو عرضه.", ["star group", "stars", "optional label/value"], ["editable", "read-only", "half rating"], ["small", "medium", "large"], states=["default", "pressed", "selected", "half", "disabled"], accessibility="مجموعة radio بتسميات رقمية وحالة محددة.", keyboard=["Tab", "Arrow keys"], aria=["role=radiogroup", "role=radio", "aria-checked"], rules=["UDS-COMP-RATING-001"]),

    component("checkbox", "مربع الاختيار", "forms-and-inputs", "forms-and-inputs/checkbox", "اختيار ثنائي أو صفر/عدة من مجموعة.", "للخيارات المستقلة أو المتعددة.", ["input", "label", "help", "alert"], states=["unchecked", "checked", "focus", "disabled", "error"], accessibility="native input مرتبط بـlabel؛ الحالة معلنة تلقائيًا.", keyboard=["Tab", "Space"], aria=["aria-label or aria-labelledby only when necessary"], dont="لا تستخدمه لواحد فقط من خيارات متنافية.", rules=["UDS-COMP-CHECKBOX-001", "UDS-A11Y-021"]),
    component("datepicker", "محدد التاريخ", "forms-and-inputs", "forms-and-inputs/datepicker", "إدخال أو اختيار تاريخ.", "للمواعيد والحجوزات والميلاد مع إدخال لوحة مفاتيح وتقويم.", ["month/year", "date input", "calendar grid", "today", "selected date", "navigation buttons", "actions"], ["single month", "dual month"], states=["closed", "open", "selected", "focus", "disabled", "error"], accessibility="حوار مسمى؛ focus للتاريخ المختار/اليوم؛ أعلن الشهر والسنة.", keyboard=["Tab", "Arrow keys", "Enter", "Escape"], aria=["role=dialog", "aria-labelledby", "aria-describedby", "aria-live"], rtl="اعكس أزرار الشهر السابق/التالي.", rules=["UDS-COMP-DATE-001"]),
    component("input", "المدخلات", "forms-and-inputs", "forms-and-inputs/input", "إدخال بيانات أحادية السطر.", "للنص أو البريد أو الهاتف أو كلمة المرور أو بحث وفق type الصحيح.", ["label", "editable area", "icon", "feedback icon", "help", "prefix", "suffix"], ["standard", "with icon", "prefix/suffix", "read-only", "filled default", "filled light", "filled dark"], states=["default", "hover", "focus", "filled", "read-only", "disabled", "error", "success"], accessibility="type صحيح وlabel مرتبط وhelp/error موصولان.", keyboard=["Tab", "Shift+Tab"], aria=["aria-describedby", "aria-invalid", "aria-label only when visual label is unavailable"], content="لا تستخدم placeholder بدل label.", rules=["UDS-COMP-INPUT-001", "UDS-A11Y-008", "UDS-A11Y-009", "UDS-A11Y-010"]),
    component("file-uploader", "رفع الملفات", "forms-and-inputs", "forms-and-inputs/file-uploader", "اختيار ورفع ملف أو ملفات.", "للسحب/الإفلات أو الاستعراض مع معاينة وحالة وحذف.", ["dropzone", "title", "help/accepted types", "browse button", "status icon", "filename", "file help", "delete"], ["single", "multiple"], states=["default", "hover", "drag", "loading", "success", "error", "disabled"], accessibility="يوفر مسار لوحة مفاتيح مكافئ للسحب والإفلات ويعلن الحالة.", keyboard=["Tab", "Shift+Tab", "Enter", "Space"], aria=["aria-label for upload area", "live status"], rules=["UDS-COMP-UPLOAD-001"]),
    component("radio", "زر الاختيار", "forms-and-inputs", "forms-and-inputs/radio", "اختيار واحد من مجموعة.", "لواحد فقط من خيارات متنافية.", ["radio input", "label", "help", "alert"], states=["unchecked", "checked", "focus", "disabled", "error"], accessibility="fieldset/legend وlabels وname مشترك.", keyboard=["Tab", "Arrow keys", "Space"], aria=["aria-label only when necessary"], dont="لا تستخدمه للاختيار المتعدد.", rules=["UDS-COMP-RADIO-001", "UDS-A11Y-021"]),
    component("slider", "شريط التمرير", "forms-and-inputs", "forms-and-inputs/slider", "اختيار قيمة أو نطاق بالسحب.", "للصوت/السطوع/السعر أو نطاق ذي feedback فوري.", ["label", "help", "track", "thumb", "range thumbs", "value", "min/max"], ["single value", "range"], states=["default", "hover", "focus", "active", "disabled", "error"], accessibility="اعرض min/max/current واسمًا واضحًا ومؤشر focus.", keyboard=["Tab", "Arrow keys", "Home", "End", "Page Up", "Page Down"], aria=["role=slider", "aria-valuemin", "aria-valuemax", "aria-valuenow", "aria-label"], rtl="سلوك زيادة القيمة/اتجاه المسار غير منشور تفصيليًا.", rules=["UDS-A11Y-020"]),
    component("steps", "الخطوات", "forms-and-inputs", "forms-and-inputs/steps", "إظهار تقدم عملية متعددة الخطوات.", "للنماذج والعمليات المتسلسلة.", ["step base/number", "name", "description", "connector", "first/middle/final"], ["horizontal", "vertical"], states=["completed", "current", "upcoming", "default", "hover", "focus"], accessibility="ol للتسلسل وaria-current للخطوة الحالية ونص حالة.", keyboard=["Tab", "Enter", "Space when interactive"], aria=["aria-label=Progress", "aria-current=step"], rtl="الخطوات الأفقية تتقدم من اليمين إلى اليسار.", responsive="قالب النموذج يستخدم radial stepper على الجوال.", rules=["UDS-COMP-STEPS-001", "UDS-FORM-004", "UDS-FORM-005"]),
    component("switch", "زر التبديل", "forms-and-inputs", "forms-and-inputs/switch", "تغيير فوري بين حالتين.", "لإعداد on/off يحدث أثره فورًا.", ["control", "label", "help", "alert"], states=["off", "on", "focus", "disabled", "error"], accessibility="اسم واضح وحالة checked تتحدث فورًا.", keyboard=["Tab", "Space"], aria=["role=switch", "aria-checked", "aria-label or label"], dont="لا تستخدمه لاختيار ينتظر زر حفظ دون توضيح.", rules=["UDS-A11Y-019"]),
    component("textarea", "منطقة النص", "forms-and-inputs", "forms-and-inputs/textarea", "إدخال نص متعدد الأسطر.", "للتعليقات أو الأوصاف أو الرسائل الطويلة.", ["label", "editable area", "help", "error", "scrollbar", "resize handle"], ["standard resizable", "no-scroll resizable", "non-resizable", "filled default", "filled light", "filled dark"], states=["default", "focus", "filled", "read-only", "disabled", "error", "success"], accessibility="label وaria-describedby ودخول focus عبر Tab.", keyboard=["Tab"], aria=["aria-describedby", "aria-invalid when invalid"], rules=["UDS-COMP-TEXTAREA-001"]),
    component("number-input", "مدخلات الأرقام", "forms-and-inputs", "forms-and-inputs/number-input", "إدخال وتعديل قيمة رقمية.", "لرقم يدوي مع زيادة/نقص وحدود عند الحاجة.", ["label", "input", "increment", "decrement", "placeholder", "help"], states=["default", "focus", "error", "disabled"], accessibility="أعلن min/max/current والقيمة غير الصالحة.", keyboard=["Tab", "Arrow keys", "Enter when confirmation is needed"], aria=["role=spinbutton", "aria-valuemin", "aria-valuemax", "aria-valuenow", "aria-invalid"], rules=["UDS-COMP-NUMBER-001"]),

    component("loading", "جاري التحميل", "loading-and-status", "loading-and-status/loading", "إظهار عملية غير محددة المدة.", "عندما يجب الانتظار ولا تتوفر نسبة تقدم.", ["circular indicator", "optional status text"], states=["loading"], accessibility="status عادة وalert فقط للعاجل؛ لا focus؛ وفر نصًا وتقليل حركة.", keyboard=NP, aria=["role=status", "role=alert when critical", "aria-live"], dont="لا تستخدمه لتقدم معروف يمكن عرضه بنسبة.", rules=["UDS-COMP-LOADING-001", "UDS-A11Y-013", "UDS-A11Y-024"]),
    component("progress-bar", "شريط التقدم", "loading-and-status", "loading-and-status/progress-bar", "عرض تقدم معروف لمهمة.", "للرفع أو المعالجة أو إرسال نموذج عندما تتوفر قيمة حالية.", ["container", "fill", "label", "percentage", "help", "success/error label", "status icon"], states=["loading", "success", "error"], accessibility="progressbar مع min/max/now وlabel وتحديثات live مناسبة.", aria=["role=progressbar", "aria-valuemin", "aria-valuemax", "aria-valuenow", "aria-label", "aria-live"], responsive="يعرض بصورة صحيحة على المقاسات المختلفة.", rules=["UDS-A11Y-018"]),
    component("radial-stepper", "شريط التقدم الدائري", "loading-and-status", "loading-and-status/radial-stepper", "إظهار تقدم دائري في عملية خطوات.", "خصوصًا لعملية متعددة الخطوات على الجوال.", ["ring", "current/total", "title", "description", "next label", "previous label"], states=["current", "completed", "error"], accessibility="progressbar بقيم وعلاقات عنوان/وصف.", keyboard=["Tab", "Enter", "Space when steps are interactive"], aria=["role=progressbar", "aria-valuemin", "aria-valuemax", "aria-valuenow", "aria-labelledby", "aria-describedby"], responsive="مخصص لعرض تقدم مضغوط على الجوال.", rules=["UDS-FORM-005"]),
    component("skeleton", "الهياكل", "loading-and-status", "loading-and-status/skeleton", "Placeholder يشبه تخطيط المحتوى أثناء الجلب.", "للصفحات والقوائم والصور التي تحتاج وقت تحميل.", ["square", "rectangle", "line", "circle", "shimmer"], states=["loading"], accessibility="أعلن التحميل ثم أزل skeleton من شجرة الوصول بعد ظهور المحتوى.", aria=["role=status", "role=alert when critical", "aria-live=polite", "aria-hidden after completion"], responsive="يحاكي التخطيط الفعلي في كل عرض.", dont="لا تتركه بعد اكتمال التحميل.", rules=["UDS-A11Y-023", "UDS-A11Y-024"]),

    component("breadcrumbs", "مسار التصفح", "navigational", "navigational/breadcrumbs", "توضيح موضع الصفحة في الهرمية.", "للصفحات الهرمية وتمكين الرجوع للمستويات الأعلى.", ["root", "separator", "middle", "overflow", "current page"], ["full", "abbreviated", "mobile back-only"], states=["default", "hover", "focus", "current"], accessibility="nav + list، اسم المنطقة، والصفحة الحالية معلنة.", keyboard=["Tab", "Enter"], aria=["aria-label=Breadcrumb", "aria-current=page"], rtl="اعكس سهم الرجوع.", responsive="Large–5XL كامل حتى الضيق؛ medium مختصر؛ small/XS السابق وسهم فقط.", rules=["UDS-COMP-BREADCRUMB-001", "UDS-COMP-BREADCRUMB-002"]),
    component("menu", "القائمة", "navigational", "navigational/menu", "عرض خيارات على سطح مؤقت.", "لعناصر يمكن تجميعها بعناوين وفواصل.", ["group title", "item", "leading icon", "trailing control/tag", "divider", "container"], states=["closed", "open", "hover", "focus", "selected", "disabled"], accessibility="تفاصيل النمط الكامل غير منشورة؛ يجب أن يبقى focus ظاهرًا.", keyboard=NP, aria=NP),
    component("pagination", "ترقيم الصفحات", "navigational", "navigational/pagination", "تقسيم مجموعة كبيرة إلى صفحات.", "للتنقل التسلسلي أو المباشر بين صفحات نتائج.", ["previous", "page items", "active page", "next"], states=["default", "hover", "focus", "current", "disabled"], accessibility="nav مسمى والصفحة الحالية معلنة والروابط قابلة للـTab.", keyboard=["Tab", "Enter", "optional Arrow keys"], aria=["aria-label=Pagination", "aria-current=page"], rtl="اعكس السابق/التالي والأيقونات.", responsive="اختصر الأرقام دون إخفاء الحالية.", rules=["UDS-COMP-PAGINATION-001"]),
    component("tabs", "قائمة علامات التبويب", "navigational", "navigational/tabs", "التنقل بين فئات معلومات مترابطة.", "لمنع الانتقال بين صفحات منفصلة عندما تكون المشاهد مرتبطة.", ["container", "tab title", "icon", "selection indicator", "more", "divider", "panels"], ["horizontal", "vertical"], states=["default", "hover", "pressed", "focus", "disabled", "selected"], accessibility="tablist/tab/tabpanel مع roving focus وتباين للحالية.", keyboard=["Tab", "Arrow keys"], aria=["role=tablist", "role=tab", "role=tabpanel", "aria-selected", "aria-controls", "tabindex"], rtl="اتجاه الترتيب والأسهم RTL.", responsive="زر المزيد لمعالجة overflow وفق المكون.", rules=["UDS-A11Y-016"]),
    component("slide-out", "القائمة الجانبية المنسدلة", "navigational", "navigational/slide-out", "لوحة جانبية لمحتوى أو خيارات إضافية.", "لوصول سريع إلى مجموعات من دون تشويش الواجهة الأساسية.", ["top title/description", "grouped sections", "dividers", "scrollbar", "frame", "actions", "close"], states=["closed", "open", "focus"], accessibility="تسمية الإغلاق وكل العناصر التفاعلية keyboard مع focus ظاهر.", keyboard=["Tab", "Enter", "Space"], aria=["role=menu", "role=menuitem", "aria-label for close"], rtl="تظهر من الجانب المنطقي المناسب.", responsive="ملائمة لتطبيقات الويب والجوال."),

    component("search-box", "حقل البحث", "search-and-filters", "search-and-filters/search-box", "إدخال استعلام والعثور على نتائج.", "للبحث النصي مع clear أو voice اختياري.", ["input", "placeholder", "search icon", "clear", "voice icon"], states=["default", "hover", "pressed", "focus", "read-only", "disabled"], accessibility="منطقة بحث وlabel واضح؛ placeholder لا يستبدل label.", keyboard=["Tab", "Enter", "Escape"], aria=["role=search", "aria-label or aria-labelledby"], content="placeholder يقدم مثالًا ويختفي عند الكتابة.", rules=["UDS-COMP-SEARCH-001"]),
    component("tags", "العلامات", "search-and-filters", "search-and-filters/tags", "نقل معلومة أو حالة أو إجراء موجز.", "للوسوم القياسية أو حالة عنصر/عملية.", ["container", "text", "leading/trailing icon", "status indicator"], ["standard", "status", "selected", "neutral", "inverse", "subtle", "transparent"], states=["default", "hover", "focus", "active", "disabled"], accessibility="أعلن الدور والحالة والفعل؛ التفاعلي زر keyboard؛ contrast كافٍ.", keyboard=["Tab", "Enter", "Space"], aria=["aria-label", "aria-live for removal"], rtl="تتدفق مجموعات العلامات RTL.", do="اجمع الحالات ذات الصلة واستخدم كلمات تصف العنصر/الحالة.", dont="لا تخلط حالات غير مرتبطة.", rules=["UDS-COMP-TAGS-001"]),
    component("filtration", "التصفية", "search-and-filters", "search-and-filters/filtration", "تضييق النتائج بمعايير محددة.", "للفئات والسمات مع حالة واضحة وreset.", ["filter trigger", "active count", "panel", "applied removable filters", "multi-select search", "show more", "reset"], states=["closed", "open", "selected", "loading", "results-updated"], accessibility="اختر role حسب نوع الخيارات وأعلن تحديث النتائج.", keyboard=["Tab", "Enter", "Space", "Escape"], aria=["role=listbox or menu", "role=option/checkbox/radio", "aria-expanded", "aria-live=polite"], rtl="اعرض المرشحات المطبقة RTL.", responsive="استخدم لوحة ملائمة للجوال دون حجب التحكمات.", rules=["UDS-COMP-FILTER-001", "UDS-COMP-FILTER-002"]),

    component("navigation-header", "شريط التنقل العلوي", "ui-shell", "ui-shell/navigation-header", "هوية وروابط وإجراءات أساسية أعلى الصفحة.", "كهيكل تنقل رئيسي متكرر.", ["brand logo", "navigation links", "actions", "optional icon/help/badge"], states=["default", "hover", "pressed", "focus", "active", "disabled"], accessibility="header/nav landmarks وروابط/أزرار دلالية وcurrent/focus واضح.", keyboard=["Tab", "Enter", "Space"], aria=["aria-label for navigation", "aria-current"], rtl="ترتيب العناصر RTL.", responsive="يتحول إلى قائمة/درج في الجوال؛ تفاصيل API غير منشورة."),
    component("navigation-drawer", "قائمة التنقل الجانبية", "ui-shell", "ui-shell/navigation-drawer", "لوحة جانبية لروابط وأقسام فرعية.", "للتنقل الجانبي أو تحول قائمة الجوال.", ["items", "submenus", "expand/collapse arrows"], states=["closed", "open", "current", "hover", "focus", "expanded", "disabled"], accessibility="navigation وexpanded؛ إدارة focus عند فتح/إغلاق القائمة الفرعية.", keyboard=["Tab", "Enter", "Arrow keys"], aria=["role=navigation", "aria-expanded"], rtl="تظهر من الجانب المنطقي.", responsive="مناسبة لتحول التنقل على الشاشات الصغيرة.", rules=["UDS-COMP-DRAWER-001"]),
    component("table-of-content", "جدول المحتويات", "ui-shell", "ui-shell/table-of-content", "مخطط قابل للتنقل لمحتوى طويل.", "للانتقال السريع بين الأقسام والعناوين المتداخلة.", ["title", "current indicator", "hierarchy markers", "section links", "nested links"], states=["default", "hover", "pressed", "focus", "current"], accessibility="navigation مسمى، current، focus، ورابط تخطي للمحتوى.", keyboard=["Tab", "Enter"], aria=["role=navigation", "aria-label", "aria-current"], rtl="المسافة البادئة من الطرف المنطقي.", responsive=NP, rules=["UDS-COMP-TOC-001"]),
    component("second-nav-header", "شريط التنقل الثانوي", "ui-shell", "ui-shell/second-nav-header", "معلومات سياقية وإجراءات سريعة فوق التنقل الأساسي.", "للطقس والتاريخ والوقت والموقع وإجراءات إضافية عند الحاجة.", ["weather/status", "date", "time", "location", "quick actions"], states=["default", "focus", "updated"], accessibility="اسم للمنطقة وتسميات وصفية للقيم والأيقونات.", keyboard=["Tab", "Enter", "Space"], aria=["aria-label", "aria-describedby", "aria-hidden for decorative icons"], rtl="ترتيب المعلومات RTL.", responsive=NP),
    component("footer", "التذييل", "ui-shell", "ui-shell/footer", "روابط ومعلومات اتصال واجتماعية وقانونية في نهاية الصفحة.", "لإنهاء shell وتوفير معلومات/روابط مهمة.", ["group labels", "links", "social icons", "accessibility tools", "legal/copyright", "optional subscription"], states=["default", "hover", "focus", "error", "success"], accessibility="footer/contentinfo، عناوين مجموعات، links keyboard، وأسماء للأيقونات.", keyboard=["Tab", "Enter"], aria=["role=contentinfo", "aria-label for icon links"], rtl="مجموعات وتدفق RTL.", responsive="تتحول المجموعات إلى رص مناسب؛ تفاصيل التحول غير منشورة.", rules=["UDS-COMP-FOOTER-001"]),
]


def template(
    template_id,
    name,
    path,
    use_case,
    documented_sections,
    required_sections=NP,
    optional_sections=NP,
    required_components=NP,
    optional_components=NP,
    layout=NP,
    header_type="Navigation Header",
    navigation=NP,
    hero=NP,
    main_content=NP,
    cta=NP,
    footer="Footer",
    responsive_rules=NP,
    rtl="Arabic interface follows RTL; template-specific RTL details are not separately published.",
    accessibility=NP,
    content_rules=NP,
    rules=None,
):
    return {
        "template_id": template_id,
        "template": name,
        "official": True,
        "use_case": use_case,
        "documented_sections": documented_sections,
        "required_sections": required_sections,
        "optional_sections": optional_sections,
        "component_hierarchy": documented_sections,
        "required_components": required_components,
        "optional_components": optional_components,
        "layout": layout,
        "header_type": header_type,
        "navigation": navigation,
        "hero": hero,
        "main_content": main_content,
        "cta": cta,
        "footer": footer,
        "responsive_rules": responsive_rules,
        "rtl": rtl,
        "accessibility": accessibility,
        "content_rules": content_rules,
        "rules": rules or [],
        "sources": [TBASE + path],
        "source_page_title": name,
        "verification_date": VERIFIED,
    }


TEMPLATES = [
    template("UDS-TPL-HAJJ", "قالب الحج 2026", "hajj-template", "منصة/حملة لموسم الحج.", ["Header", "campaign hero", "content sections", "Footer", "Ihsan floating element"], optional_sections=["hero color/background/image alternatives", "motion"], required_components=["Navigation Header", "Footer"], hero="خيارات لون/صورة/عنصر موسمي مع الخط السعودي.", main_content="أقسام الحملة والخدمات/المعلومات.", cta="Campaign CTA where shown.", responsive_rules="حافظ على القراءة والوصول عبر الشاشات؛ التفاصيل الرقمية تتبع Foundations.", accessibility="التباين والبدائل والkeyboard العامة مطلوبة.", content_rules="محتوى الحج والهوية الموسمية فقط.", rules=["UDS-TEMPLATE-CAMPAIGN-001"]),
    template("UDS-TPL-FOUNDING-DAY", "قالب يوم التأسيس 2026 م", "founding-day", "حملة يوم التأسيس.", ["Header", "historical hero", "images/illustrations", "content", "Footer", "Ihsan floating element"], optional_sections=["motion", "visual alternatives"], required_components=["Navigation Header", "Footer"], hero="عمارة تاريخية وصور وهوية المناسبة.", main_content="قصة/معلومات المناسبة.", cta="Campaign CTA where shown.", responsive_rules="تتكيف الصور/النص ولا يحجب العنصر العائم المحتوى.", accessibility="بدائل الصور وتقليل الحركة والتباين.", content_rules="هوية ومحتوى يوم التأسيس.", rules=["UDS-TEMPLATE-CAMPAIGN-001"]),
    template("UDS-TPL-NATIONAL-DAY", "قالب اليوم الوطني 95", "national-day", "حملة اليوم الوطني.", ["Header", "campaign hero", "leaders/illustrations/photos", "content", "Footer"], optional_sections=["motion", "dark-green or default footer"], required_components=["Navigation Header", "Footer"], hero="بدائل القادة والرسوم والصور.", main_content="أقسام المناسبة.", cta="Campaign CTA where shown.", responsive_rules="الوسائط والحركة متكيفة وقابلة للوصول.", accessibility="بدائل للصور وتقليل الحركة والتباين.", content_rules="محتوى وهوية اليوم الوطني.", rules=["UDS-TEMPLATE-CAMPAIGN-001"]),
    template("UDS-TPL-HOME", "قالب الصفحة الرئيسية", "home-page", "الواجهة الرئيسية لمنصة حكومية.", ["Header", "Hero + primary CTA", "services/features", "news/related content", "feedback", "last updated", "Footer"], required_sections=["Header", "Hero", "main content", "Footer"], optional_sections=["Second Navigation Header", "search autocomplete", "feedback", "campaign logo"], required_components=["Navigation Header", "Button/Link", "Card", "Footer"], optional_components=["Second Navigation Header", "Search Box", "Feedback/Rating"], layout="Official container/grid/spacing; hero followed by service/content sections.", navigation="Primary navigation; mobile drawer transformation.", hero="High-quality responsive image or approved visual; legible text and clear CTA.", main_content="Services/features/news arranged with official cards and headings.", cta="One clear primary action; view-all near related content.", responsive_rules="Stack long heading and CTA vertically; preserve image/text legibility.", accessibility="Keyboard search/clear, alt text, headings, contrast, focus, touch targets.", content_rules="Arabic-first concise headings, descriptive CTA, last-updated dates.", rules=["UDS-TEMPLATE-HOME-001", "UDS-TEMPLATE-HOME-002", "UDS-TEMPLATE-HOME-003", "UDS-TEMPLATE-HOME-004"]),
    template("UDS-TPL-CONTACT", "قالب صفحة التواصل", "contact-us-page", "قنوات ونموذج التواصل.", ["Header", "page heading", "contact channels/form", "form states", "feedback", "Footer"], required_sections=["Header", "contact content", "Footer"], optional_sections=["contact form", "feedback"], required_components=["Navigation Header", "Footer"], optional_components=["Input", "Textarea", "Button", "Notification"], main_content="قنوات الاتصال أو نموذج مع حالات واضحة.", cta="إرسال الطلب عند وجود نموذج.", responsive_rules="حقول وقنوات مرنة على الجوال.", accessibility="Labels/errors/status/keyboard for form.", content_rules="بيانات الاتصال وتعليمات واضحة."),
    template("UDS-TPL-FORM", "قالب صفحة النموذج", "form-page", "إدخال بيانات أو إكمال خدمة متعددة الخطوات.", ["Header", "introduction", "step progress", "fields", "validation", "actions", "Footer"], required_sections=["Header", "form", "actions", "Footer"], optional_sections=["multi-step progress", "feedback"], required_components=["Form inputs", "Button"], optional_components=["Steps", "Radial Stepper", "Notification", "File Uploader"], layout="خطوة وعنوان وتعليمات ثم مجموعة حقول وإجراءات.", navigation="Breadcrumb when hierarchical.", main_content="Fields grouped by task step.", cta="Primary submit/next with secondary previous/cancel as applicable.", responsive_rules="Numbered Steps on large screens; Radial Stepper on mobile.", accessibility="Labels, fieldsets, errors, focus, keyboard, status.", content_rules="State required information and concise instructions before fields.", rules=["UDS-FORM-001", "UDS-FORM-002", "UDS-FORM-003", "UDS-FORM-004", "UDS-FORM-005"]),
    template("UDS-TPL-HELP", "قالب مركز المساعدة", "help-page", "مساعدة المستخدم والوصول إلى الدعم.", ["Header", "page heading", "search/help cards", "contact channels", "feedback", "Footer"], required_sections=["Header", "help content", "Footer"], optional_sections=["Search Box", "feedback", "contact channels"], required_components=["Navigation Header", "Footer"], optional_components=["Search Box", "Card", "Accordion"], main_content="بطاقات/أقسام مساعدة ومسارات دعم.", cta="انتقال واضح إلى الحل أو قناة التواصل.", responsive_rules="رص البطاقات والتنقل في الجوال.", accessibility="روابط وبحث وبطاقات دلالية قابلة للkeyboard.", content_rules="لغة مباشرة تصف المشكلة والحل."),
    template("UDS-TPL-FEEDBACK", "قالب التعليقات", "feedback-section", "جمع رأي المستخدم في فائدة الصفحة.", ["question", "yes/no choice", "reason choices/input", "submit", "confirmation", "mobile state"], required_sections=["question", "response control", "confirmation"], optional_sections=["reason follow-up"], required_components=["Radio or equivalent choice", "Button", "Notification"], header_type=NP, navigation=NP, main_content="هل كانت هذه الصفحة مفيدة؟ ثم سبب عند الحاجة.", cta="إرسال الملاحظات.", footer=NP, responsive_rules="Mobile layout shown by template.", accessibility="Choice group labels, keyboard, status confirmation.", content_rules="سؤال موجز وأسباب واضحة.", rules=["UDS-TEMPLATE-FEEDBACK-001"]),
    template("UDS-TPL-SERVICE", "صفحة الخدمة", "service-page", "شرح خدمة حكومية وتمكين المستخدم من تنفيذها.", ["Header", "Breadcrumb", "service summary", "requirements/steps/content", "primary action", "feedback", "Footer"], required_sections=["Header", "service content", "primary action", "Footer"], optional_sections=["Breadcrumb", "feedback"], required_components=["Navigation Header", "Button/Link", "Footer"], optional_components=["Breadcrumbs", "Steps", "Accordion", "Feedback"], layout="مقدمة الخدمة ثم المتطلبات/الخطوات والإجراء.", navigation="Primary navigation and Breadcrumb when hierarchical.", main_content="تعريف الخدمة والمتطلبات والخطوات والمعلومات.", cta="بدء/طلب الخدمة.", responsive_rules="حافظ على إتمام المهمة على الجوال.", accessibility="عناوين واضحة، keyboard، focus، contrast، touch.", content_rules="محتوى مباشر يركز على المهمة."),
    template("UDS-TPL-FAQ", "صفحة الأسئلة الشائعة", "faqs-page", "إجابة أسئلة متكررة قابلة للبحث والتصنيف.", ["Header", "heading", "optional search", "optional classifications", "Accordion answers", "optional pagination", "optional answer rating", "Footer"], required_sections=["Header", "questions/answers", "Footer"], optional_sections=["Search when >20", "classifications when >20", "pagination after 10", "answer rating"], required_components=["Accordion"], optional_components=["Search Box", "Tags/filters", "Pagination", "Rating"], navigation="Two languages direct switch; more than two dropdown.", main_content="أسئلة وأجوبة مصنفة.", cta="Remove/reset filters and rating submit where applicable.", responsive_rules="Mobile maximum five category controls; otherwise dropdown.", accessibility="Accordion/search/filter/pagination/rating semantics.", content_rules="أسئلة مباشرة وإجابات موجزة؛ highlight search query.", rules=["UDS-TEMPLATE-FAQ-001", "UDS-TEMPLATE-FAQ-002", "UDS-TEMPLATE-FAQ-003", "UDS-TEMPLATE-FAQ-004"]),
    template("UDS-TPL-SITEMAP", "صفحة خريطة الموقع", "sitemap-page", "عرض بنية روابط المنصة.", ["Header", "page heading", "grouped internal/external links", "Footer"], required_sections=["Header", "link hierarchy", "Footer"], optional_sections=NP, required_components=["List", "Link", "Footer"], navigation="Hierarchical groups of destinations.", main_content="روابط داخلية وخارجية منظمة.", cta=NP, responsive_rules="قوائم متكيفة دون قص.", accessibility="nav/list semantics and descriptive links.", content_rules="عناوين مجموعات وروابط وجهة واضحة."),
    template("UDS-TPL-404", "صفحة الخطأ", "page-not-found", "استعادة المستخدم من مسار غير موجود.", ["Header", "clear error message", "recovery action", "Footer"], required_sections=["error message", "recovery action"], optional_sections=["Header", "Footer"], required_components=["Button or Link"], main_content="شرح واضح لعدم العثور على الصفحة.", cta="العودة/الانتقال إلى مسار مفيد.", responsive_rules="رسالة وإجراء ظاهران على الجوال.", accessibility="Heading/message/action keyboard and focus.", content_rules="لا تستخدم رمز خطأ بلا شرح.", rules=["UDS-TEMPLATE-404-001"]),
    template("UDS-TPL-SEARCH", "صفحة البحث", "search-page", "البحث والفرز والتصفية داخل المحتوى.", ["Header", "Search Box", "language control", "filters", "applied filters", "sort", "results", "pagination", "Footer"], required_sections=["Search Box", "results"], optional_sections=["language switch", "filters", "sort", "pagination"], required_components=["Search Box"], optional_components=["Filtration", "Tags", "Card/List", "Pagination", "Dropdown"], layout="بحث في الأعلى ثم أدوات ثم نتائج/ترقيم.", navigation="Language control and result links.", main_content="نتائج قابلة للنقر مع تمييز نوع الرابط الخارجي/الملف.", cta="Clear/reset/remove filters and result link.", responsive_rules="Filters collapse to a mobile-appropriate control; chips flow RTL.", accessibility="Search/filters/results status/pagination semantics.", content_rules="Query/result labels واضحة؛ external/file destinations identified.", rules=["UDS-TEMPLATE-SEARCH-001", "UDS-TEMPLATE-SEARCH-002"]),
    template("UDS-TPL-E-PARTICIPATION", "صفحة المشاركة الإلكترونية", "e-participation-page", "عرض قنوات وبيانات المشاركة الإلكترونية.", ["Header", "participation cards", "open data", "performance statistics", "charts", "Footer"], required_sections=["Header", "participation content", "Footer"], optional_sections=["open data", "statistics/charts"], required_components=["Navigation Header", "Footer"], optional_components=["Card", "Metric", "Charts", "Table"], main_content="قنوات مشاركة وبيانات وإحصاءات.", cta="CTA واضح على البطاقة عندما يكون مطلوبًا.", responsive_rules="بطاقات ورسوم وبيانات متكيفة.", accessibility="Chart alternatives, descriptive links, keyboard cards.", content_rules="عرّف البيانات والأداء والمشاركة بوضوح."),
    template("UDS-TPL-ABOUT", "حول الكيان", "about-page", "معلومات مؤسسية عن الجهة.", ["Header", "organization", "strategy", "policies/laws", "budget/expenditure", "procurement", "participation", "partners", "sustainability", "careers", "news/events", "contact", "Footer"], required_sections=["Header", "entity overview", "Footer"], optional_sections=["بقية الأقسام بحسب الجهة"], required_components=["Navigation Header", "Footer"], optional_components=["Card", "List", "Table", "Accordion", "Charts"], navigation="TOC/Breadcrumb when content depth warrants.", main_content="محتوى مؤسسي متعدد الأقسام.", cta="روابط إلى السياسات والوظائف والأخبار والتواصل.", responsive_rules="أقسام طويلة قابلة للمسح وإعادة التدفق.", accessibility="Heading hierarchy, TOC/list/table semantics, alt text.", content_rules="معلومات رسمية واضحة ومحدثة."),
    template("UDS-TPL-CONTENT", "صفحة المحتوى", "content-page", "نشر محتوى حكومي طويل أو مرجعي.", ["Header", "Breadcrumb", "title/introduction", "language control", "Table of Content", "headings/lists/media", "feedback", "Footer"], required_sections=["title", "main content"], optional_sections=["Header", "Breadcrumb", "language control", "TOC", "feedback", "Footer"], required_components=NP, optional_components=["Breadcrumbs", "Table of Content", "List", "Quote", "Code Snippet", "Feedback"], layout="Paragraph measure up to 720px token; hierarchy and whitespace.", navigation="Breadcrumb/TOC according to depth.", main_content="Headings, paragraphs, lists, and media.", cta=NP, responsive_rules="TOC/media/content reflow without clipping.", accessibility="Heading hierarchy, alt text, keyboard TOC, contrast.", content_rules="Arabic-first, clear headings, descriptive links.", rules=["UDS-TEMPLATE-CONTENT-001"]),
    template("UDS-TPL-COOKIES", "لافتة ملفات تعريف الارتباط", "cookies-banner", "إبلاغ المستخدم وإدارة اختيارات ملفات الارتباط.", ["content", "actions", "error handling", "cookie management"], required_sections=["message", "actions"], optional_sections=["preferences management", "error state"], required_components=["Button/Link"], header_type=NP, navigation=NP, main_content="شرح وإجراءات إدارة ملفات الارتباط.", cta="قبول/رفض/إدارة بحسب سياسة الجهة؛ التفاصيل القانونية غير منشورة.", footer=NP, responsive_rules="لا تحجب المحتوى أو الإجراءات على الجوال.", accessibility="Keyboard, focus, clear labels, error status.", content_rules="موجز وواضح؛ المتطلبات القانونية التفصيلية تحتاج مصدر الجهة."),
    template("UDS-TPL-CHATBOT", "روبوت الدردشة", "chatbot", "مساعدة حوارية داخل المنصة.", ["intro/welcome", "features", "conversation area", "position/launcher", "close"], required_sections=["welcome/context", "conversation", "open/close control"], optional_sections=["feature suggestions"], required_components=["Floating Button or launcher", "dialog/panel", "Input", "Button"], header_type=NP, navigation=NP, main_content="محادثة وإرشاد المستخدم.", cta="إرسال/اختيار اقتراح وإغلاق.", footer=NP, responsive_rules="موضع لا يحجب المحتوى والتحكمات.", accessibility="Accessible names, keyboard, focus management, status updates.", content_rules="رسائل واضحة وسياق ترحيبي.", rules=["UDS-TEMPLATE-CHATBOT-001"]),
    template("UDS-TPL-RATING", "قسم التقييم", "rating-section", "جمع تقييم الصفحة أو المحتوى.", ["rating prompt", "rating control", "submit", "confirmation", "mobile state"], required_sections=["prompt", "rating", "confirmation"], optional_sections=["submit when not immediate"], required_components=["Rating", "Button or immediate action", "Notification"], header_type=NP, navigation=NP, main_content="اختيار درجة وتأكيد النتيجة.", cta="إرسال إذا كان المكون لا يحفظ فورًا.", footer=NP, responsive_rules="هدف لمس وترتيب مناسب للجوال.", accessibility="Radiogroup labels, arrow keyboard, announced confirmation.", content_rules="سؤال واضح وتسمية رقمية للدرجة."),
]


def write_registry(path: Path, key: str, values: list[dict]) -> None:
    payload = {
        "schema_version": "1.0.0",
        "system": "Saudi Unified Platform Code",
        "verification_date": VERIFIED,
        "not_published_marker": NP,
        f"{key[:-1]}_count": len(values),
        key: values,
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def validate() -> None:
    component_ids = [item["component"] for item in COMPONENTS]
    template_ids = [item["template_id"] for item in TEMPLATES]
    if len(COMPONENTS) != 50 or len(component_ids) != len(set(component_ids)):
        raise SystemExit(f"Expected 50 unique components, got {len(COMPONENTS)}")
    if len(TEMPLATES) != 19 or len(template_ids) != len(set(template_ids)):
        raise SystemExit(f"Expected 19 unique templates, got {len(TEMPLATES)}")
    required_component_fields = {
        "component", "name", "official", "group", "purpose", "usage",
        "when_to_use", "when_not_to_use", "anatomy",
        "variants", "sizes", "states", "hover", "focus", "active", "disabled",
        "error", "success", "loading", "rtl", "responsive", "accessibility",
        "keyboard", "aria", "content", "design_tokens", "do", "dont",
        "code_example", "rules", "source", "source_page_title",
        "verification_date",
    }
    required_template_fields = {
        "template_id", "template", "official", "use_case",
        "documented_sections", "required_sections", "optional_sections",
        "component_hierarchy", "required_components", "optional_components",
        "layout", "header_type", "navigation", "hero", "main_content", "cta",
        "footer", "responsive_rules", "rtl", "accessibility", "content_rules",
        "rules", "sources", "source_page_title", "verification_date",
    }

    rules_payload = json.loads((DS / "uds-rules.json").read_text(encoding="utf-8"))
    valid_rule_ids = {item["id"] for item in rules_payload["rules"]}
    inventory = {}
    inventory_row = re.compile(
        r"^\|\s*\d+\s*\|\s*(https://design\.dga\.gov\.sa/[^ ]*)"
        r"\s*\|\s*([^|]+?)\s*\|"
    )
    for line in (DS / "crawl_inventory.md").read_text(encoding="utf-8").splitlines():
        match = inventory_row.match(line)
        if match:
            inventory[match.group(1)] = match.group(2).strip()

    def validate_item(item, required_fields, label, source_urls):
        missing = required_fields - item.keys()
        if missing:
            raise SystemExit(f"{label} missing {sorted(missing)}")
        empty = [key for key in required_fields if item[key] is None or item[key] == ""]
        if empty:
            raise SystemExit(f"{label} has empty fields {sorted(empty)}")
        unknown_rules = set(item["rules"]) - valid_rule_ids
        if unknown_rules:
            raise SystemExit(f"{label} references unknown rules {sorted(unknown_rules)}")
        for source_url in source_urls:
            if source_url not in inventory:
                raise SystemExit(f"{label} source absent from inventory: {source_url}")
            if item["source_page_title"] != inventory[source_url]:
                raise SystemExit(
                    f"{label} source title mismatch: "
                    f"{item['source_page_title']} != {inventory[source_url]}"
                )
        if item["verification_date"] != VERIFIED:
            raise SystemExit(f"{label} has unexpected verification date")

    for item in COMPONENTS:
        validate_item(
            item,
            required_component_fields,
            f"component {item['component']}",
            [item["source"]],
        )
    for item in TEMPLATES:
        validate_item(
            item,
            required_template_fields,
            f"template {item['template_id']}",
            item["sources"],
        )


def main() -> None:
    validate()
    write_registry(DS / "uds-components.json", "components", COMPONENTS)
    write_registry(DS / "uds-templates.json", "templates", TEMPLATES)
    print(json.dumps({"components": len(COMPONENTS), "templates": len(TEMPLATES)}))


if __name__ == "__main__":
    main()
