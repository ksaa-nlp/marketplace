# UDS Compliance Checker

Static, dependency-free checker for the reliably automatable subset of the Saudi Unified Platform Code rule registry.

## Run

```bash
python3 tools/uds-compliance/uds_compliance.py uds-validation-demo
```

Write machine-readable and text reports:

```bash
python3 tools/uds-compliance/uds_compliance.py uds-validation-demo \
  --json-out uds-validation-demo/compliance-report.json \
  --text-out uds-validation-demo/compliance-report.txt
```

Exit codes:

- `0`: no failures; warnings may remain unless `--strict` is used.
- `1`: at least one required automated check failed.
- `2`: no failures, but `--strict` found warnings.

## What it checks

- Arabic root `lang`/`dir` and responsive viewport.
- image alternatives, control labels, invalid-field descriptions, and duplicate IDs.
- semantic buttons/links and secure new-context links.
- selected UDS component contracts declared using `data-uds-component`.
- modal, tabs, progress, switch, slider, Steps, Breadcrumb, Pagination, Search, TOC, Table, List, and Footer semantics.
- heading order and selected CSS token/hard-code signals.

The checker deliberately does **not** claim to automate visual judgment, content quality, computed contrast, interaction intent, keyboard behavior at runtime, screen-reader announcements, responsive appearance, or template suitability. Those rules remain `SEMI_AUTOMATED` or `MANUAL` in `uds-rules.json` and are listed under `MANUAL REVIEW`.

## Component annotations

For unambiguous static checking, annotate the official component root where applicable:

```html
<nav data-uds-component="breadcrumbs" aria-label="مسار التصفح">…</nav>
<form data-uds-component="search-box" role="search">…</form>
<ol data-uds-component="steps" aria-label="التقدم">…</ol>
```

These `data-uds-component` attributes are checker annotations (`INFERRED` repository tooling), not official component API claims.

## Maintenance

- `build_rules.py` regenerates the audited Markdown and JSON rule registry.
- `build_catalogs.py` regenerates the component/template JSON registries.
- Update the verification date and source audit before incorporating a new official release.

Regenerate and run the integrity/unit suite from the repository root:

```bash
python3 tools/uds-compliance/build_rules.py
python3 tools/uds-compliance/build_catalogs.py
python3 tools/uds-compliance/test_uds_compliance.py
```

The suite verifies positive and negative checker fixtures, 169 unique traceable rules, all 50 component schemas, all 19 template schemas, and that every catalog rule reference resolves.
